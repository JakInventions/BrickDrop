gdjs.JISplashScreenCode = {};
gdjs.JISplashScreenCode.GDBackgroundObjects1= [];
gdjs.JISplashScreenCode.GDBackgroundObjects2= [];
gdjs.JISplashScreenCode.GDJakLogoObjects1= [];
gdjs.JISplashScreenCode.GDJakLogoObjects2= [];

gdjs.JISplashScreenCode.conditionTrue_0 = {val:false};
gdjs.JISplashScreenCode.condition0IsTrue_0 = {val:false};
gdjs.JISplashScreenCode.condition1IsTrue_0 = {val:false};


gdjs.JISplashScreenCode.eventsList0xac5d0 = function(runtimeScene, context) {

{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LogoFade");
}{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(0);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.05, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(10);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(20);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.15, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(30);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(40);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.25, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(50);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.3, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(60);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.35, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(70);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.4, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(80);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.45, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(90);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(100);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.55, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(110);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.6, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(120);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.65, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(130);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.7, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(140);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.75, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(150);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.8, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(160);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.85, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(170);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.9, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(180);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.95, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(190);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(200);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.5, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(190);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.55, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(180);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.6, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(170);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.65, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(160);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.7, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(150);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.75, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(140);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.8, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(130);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.85, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(120);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.9, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(110);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.95, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(100);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(90);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.05, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(80);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.1, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(70);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.15, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(60);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.2, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(50);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.25, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(40);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.3, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(30);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.35, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(20);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.4, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(10);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.45, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
gdjs.JISplashScreenCode.GDJakLogoObjects1.createFrom(runtimeScene.getObjects("JakLogo"));
{for(var i = 0, len = gdjs.JISplashScreenCode.GDJakLogoObjects1.length ;i < len;++i) {
    gdjs.JISplashScreenCode.GDJakLogoObjects1[i].setOpacity(0);
}
}}

}


{


gdjs.JISplashScreenCode.condition0IsTrue_0.val = false;
{
gdjs.JISplashScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.5, "LogoFade");
}if (gdjs.JISplashScreenCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


}; //End of gdjs.JISplashScreenCode.eventsList0xac5d0


gdjs.JISplashScreenCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.JISplashScreenCode.GDBackgroundObjects1.length = 0;
gdjs.JISplashScreenCode.GDBackgroundObjects2.length = 0;
gdjs.JISplashScreenCode.GDJakLogoObjects1.length = 0;
gdjs.JISplashScreenCode.GDJakLogoObjects2.length = 0;

gdjs.JISplashScreenCode.eventsList0xac5d0(runtimeScene, context);return;
}
gdjs['JISplashScreenCode']= gdjs.JISplashScreenCode;
