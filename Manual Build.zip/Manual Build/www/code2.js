gdjs.MainGameCode = {};
gdjs.MainGameCode.GDGameIntroObjects1= [];
gdjs.MainGameCode.GDGameIntroObjects2= [];
gdjs.MainGameCode.GDGameIntroObjects3= [];
gdjs.MainGameCode.GDGameIntroObjects4= [];
gdjs.MainGameCode.GDGameIntroObjects5= [];
gdjs.MainGameCode.GDPlayerObjects1= [];
gdjs.MainGameCode.GDPlayerObjects2= [];
gdjs.MainGameCode.GDPlayerObjects3= [];
gdjs.MainGameCode.GDPlayerObjects4= [];
gdjs.MainGameCode.GDPlayerObjects5= [];
gdjs.MainGameCode.GDRightCollideObjects1= [];
gdjs.MainGameCode.GDRightCollideObjects2= [];
gdjs.MainGameCode.GDRightCollideObjects3= [];
gdjs.MainGameCode.GDRightCollideObjects4= [];
gdjs.MainGameCode.GDRightCollideObjects5= [];
gdjs.MainGameCode.GDLeftCollideObjects1= [];
gdjs.MainGameCode.GDLeftCollideObjects2= [];
gdjs.MainGameCode.GDLeftCollideObjects3= [];
gdjs.MainGameCode.GDLeftCollideObjects4= [];
gdjs.MainGameCode.GDLeftCollideObjects5= [];
gdjs.MainGameCode.GDFireballObjects1= [];
gdjs.MainGameCode.GDFireballObjects2= [];
gdjs.MainGameCode.GDFireballObjects3= [];
gdjs.MainGameCode.GDFireballObjects4= [];
gdjs.MainGameCode.GDFireballObjects5= [];
gdjs.MainGameCode.GDFireball2Objects1= [];
gdjs.MainGameCode.GDFireball2Objects2= [];
gdjs.MainGameCode.GDFireball2Objects3= [];
gdjs.MainGameCode.GDFireball2Objects4= [];
gdjs.MainGameCode.GDFireball2Objects5= [];
gdjs.MainGameCode.GDFireball3Objects1= [];
gdjs.MainGameCode.GDFireball3Objects2= [];
gdjs.MainGameCode.GDFireball3Objects3= [];
gdjs.MainGameCode.GDFireball3Objects4= [];
gdjs.MainGameCode.GDFireball3Objects5= [];
gdjs.MainGameCode.GDFireball4Objects1= [];
gdjs.MainGameCode.GDFireball4Objects2= [];
gdjs.MainGameCode.GDFireball4Objects3= [];
gdjs.MainGameCode.GDFireball4Objects4= [];
gdjs.MainGameCode.GDFireball4Objects5= [];
gdjs.MainGameCode.GDResetBoxObjects1= [];
gdjs.MainGameCode.GDResetBoxObjects2= [];
gdjs.MainGameCode.GDResetBoxObjects3= [];
gdjs.MainGameCode.GDResetBoxObjects4= [];
gdjs.MainGameCode.GDResetBoxObjects5= [];
gdjs.MainGameCode.GDScoreObjects1= [];
gdjs.MainGameCode.GDScoreObjects2= [];
gdjs.MainGameCode.GDScoreObjects3= [];
gdjs.MainGameCode.GDScoreObjects4= [];
gdjs.MainGameCode.GDScoreObjects5= [];
gdjs.MainGameCode.GDPauseButtonObjects1= [];
gdjs.MainGameCode.GDPauseButtonObjects2= [];
gdjs.MainGameCode.GDPauseButtonObjects3= [];
gdjs.MainGameCode.GDPauseButtonObjects4= [];
gdjs.MainGameCode.GDPauseButtonObjects5= [];
gdjs.MainGameCode.GDTextBoxObjects1= [];
gdjs.MainGameCode.GDTextBoxObjects2= [];
gdjs.MainGameCode.GDTextBoxObjects3= [];
gdjs.MainGameCode.GDTextBoxObjects4= [];
gdjs.MainGameCode.GDTextBoxObjects5= [];
gdjs.MainGameCode.GDLargeTextboxObjects1= [];
gdjs.MainGameCode.GDLargeTextboxObjects2= [];
gdjs.MainGameCode.GDLargeTextboxObjects3= [];
gdjs.MainGameCode.GDLargeTextboxObjects4= [];
gdjs.MainGameCode.GDLargeTextboxObjects5= [];
gdjs.MainGameCode.GDResumeButtonObjects1= [];
gdjs.MainGameCode.GDResumeButtonObjects2= [];
gdjs.MainGameCode.GDResumeButtonObjects3= [];
gdjs.MainGameCode.GDResumeButtonObjects4= [];
gdjs.MainGameCode.GDResumeButtonObjects5= [];
gdjs.MainGameCode.GDRestartButtonObjects1= [];
gdjs.MainGameCode.GDRestartButtonObjects2= [];
gdjs.MainGameCode.GDRestartButtonObjects3= [];
gdjs.MainGameCode.GDRestartButtonObjects4= [];
gdjs.MainGameCode.GDRestartButtonObjects5= [];
gdjs.MainGameCode.GDShopButtonObjects1= [];
gdjs.MainGameCode.GDShopButtonObjects2= [];
gdjs.MainGameCode.GDShopButtonObjects3= [];
gdjs.MainGameCode.GDShopButtonObjects4= [];
gdjs.MainGameCode.GDShopButtonObjects5= [];
gdjs.MainGameCode.GDHighScoreObjects1= [];
gdjs.MainGameCode.GDHighScoreObjects2= [];
gdjs.MainGameCode.GDHighScoreObjects3= [];
gdjs.MainGameCode.GDHighScoreObjects4= [];
gdjs.MainGameCode.GDHighScoreObjects5= [];
gdjs.MainGameCode.GDBackgroundObjects1= [];
gdjs.MainGameCode.GDBackgroundObjects2= [];
gdjs.MainGameCode.GDBackgroundObjects3= [];
gdjs.MainGameCode.GDBackgroundObjects4= [];
gdjs.MainGameCode.GDBackgroundObjects5= [];
gdjs.MainGameCode.GDCoinObjects1= [];
gdjs.MainGameCode.GDCoinObjects2= [];
gdjs.MainGameCode.GDCoinObjects3= [];
gdjs.MainGameCode.GDCoinObjects4= [];
gdjs.MainGameCode.GDCoinObjects5= [];
gdjs.MainGameCode.GDCoinsGainedObjects1= [];
gdjs.MainGameCode.GDCoinsGainedObjects2= [];
gdjs.MainGameCode.GDCoinsGainedObjects3= [];
gdjs.MainGameCode.GDCoinsGainedObjects4= [];
gdjs.MainGameCode.GDCoinsGainedObjects5= [];
gdjs.MainGameCode.GDInstructionsObjects1= [];
gdjs.MainGameCode.GDInstructionsObjects2= [];
gdjs.MainGameCode.GDInstructionsObjects3= [];
gdjs.MainGameCode.GDInstructionsObjects4= [];
gdjs.MainGameCode.GDInstructionsObjects5= [];
gdjs.MainGameCode.GDTapToHoldObjects1= [];
gdjs.MainGameCode.GDTapToHoldObjects2= [];
gdjs.MainGameCode.GDTapToHoldObjects3= [];
gdjs.MainGameCode.GDTapToHoldObjects4= [];
gdjs.MainGameCode.GDTapToHoldObjects5= [];
gdjs.MainGameCode.GDEdgeObjects1= [];
gdjs.MainGameCode.GDEdgeObjects2= [];
gdjs.MainGameCode.GDEdgeObjects3= [];
gdjs.MainGameCode.GDEdgeObjects4= [];
gdjs.MainGameCode.GDEdgeObjects5= [];
gdjs.MainGameCode.GDTubroBackgroundObjects1= [];
gdjs.MainGameCode.GDTubroBackgroundObjects2= [];
gdjs.MainGameCode.GDTubroBackgroundObjects3= [];
gdjs.MainGameCode.GDTubroBackgroundObjects4= [];
gdjs.MainGameCode.GDTubroBackgroundObjects5= [];
gdjs.MainGameCode.GDTurboChargeObjects1= [];
gdjs.MainGameCode.GDTurboChargeObjects2= [];
gdjs.MainGameCode.GDTurboChargeObjects3= [];
gdjs.MainGameCode.GDTurboChargeObjects4= [];
gdjs.MainGameCode.GDTurboChargeObjects5= [];
gdjs.MainGameCode.GDTurboButtonObjects1= [];
gdjs.MainGameCode.GDTurboButtonObjects2= [];
gdjs.MainGameCode.GDTurboButtonObjects3= [];
gdjs.MainGameCode.GDTurboButtonObjects4= [];
gdjs.MainGameCode.GDTurboButtonObjects5= [];
gdjs.MainGameCode.GDDirectionIndicatorObjects1= [];
gdjs.MainGameCode.GDDirectionIndicatorObjects2= [];
gdjs.MainGameCode.GDDirectionIndicatorObjects3= [];
gdjs.MainGameCode.GDDirectionIndicatorObjects4= [];
gdjs.MainGameCode.GDDirectionIndicatorObjects5= [];

gdjs.MainGameCode.conditionTrue_0 = {val:false};
gdjs.MainGameCode.condition0IsTrue_0 = {val:false};
gdjs.MainGameCode.condition1IsTrue_0 = {val:false};


gdjs.MainGameCode.eventsList0x712860 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("normal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("crateNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("slimeNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("gameRomNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("penguinNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) + ")");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setAnimationName("botNormal");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x712860
gdjs.MainGameCode.eventsList0x72c788 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "diceRoll");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).setNumber(gdjs.random(5) + 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "diceRoll");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x72c788
gdjs.MainGameCode.eventsList0x72c628 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) + ")");
}
}
{ //Subevents
gdjs.MainGameCode.eventsList0x72c788(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72c628
gdjs.MainGameCode.eventsList0x72c4d0 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72c628(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72c4d0
gdjs.MainGameCode.eventsList0x72abd8 = function(runtimeScene) {

{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)) <= 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)).setNumber(0);
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)) <= 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)).setNumber(0);
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)) >= 350 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)).setNumber(350);
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)) <= 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(9)).sub(200);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(4)).sub(200);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(8)).setString("no");
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)) >= 350 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)).setNumber(350);
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(8)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDTurboButtonObjects2.createFrom(runtimeScene.getObjects("TurboButton"));
{for(var i = 0, len = gdjs.MainGameCode.GDTurboButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDTurboButtonObjects2[i].setAnimationName("on");
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(8)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDTurboButtonObjects2.createFrom(runtimeScene.getObjects("TurboButton"));
{for(var i = 0, len = gdjs.MainGameCode.GDTurboButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDTurboButtonObjects2[i].setAnimationName("off");
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(5)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{runtimeScene.getVariables().getFromIndex(0).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}{gdjs.evtTools.storage.writeStringInJSONFile("highScore", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72c4d0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72abd8
gdjs.MainGameCode.eventsList0x72cec8 = function(runtimeScene) {

{

gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects3[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects3[i].getVariables().getFromIndex(1)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects3[k] = gdjs.MainGameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("botNormal");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].playAnimation();
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].pauseAnimation();
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x72cec8
gdjs.MainGameCode.eventsList0x72d6c8 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(4)) < (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(9))) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(4)).add(0.05);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x72d6c8
gdjs.MainGameCode.eventsList0x72d540 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(6)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72d6c8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72d540
gdjs.MainGameCode.eventsList0x72dc50 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDFireballObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDFireballObjects1[i].getVariableNumber(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(2)) < 1600 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDFireballObjects1[k] = gdjs.MainGameCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDFireballObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(8).add(0.1);
}}

}


}; //End of gdjs.MainGameCode.eventsList0x72dc50
gdjs.MainGameCode.eventsList0x72dad8 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72dc50(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72dad8
gdjs.MainGameCode.eventsList0x72cd98 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72cec8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(3)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72d540(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDFireballObjects1[i].getVariableString(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(3)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDFireballObjects1[k] = gdjs.MainGameCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDFireballObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72dad8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72cd98
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPauseButtonObjects1Objects = Hashtable.newFrom({"PauseButton": gdjs.MainGameCode.GDPauseButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLargeTextboxObjects1Objects = Hashtable.newFrom({"LargeTextbox": gdjs.MainGameCode.GDLargeTextboxObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects1Objects = Hashtable.newFrom({"ShopButton": gdjs.MainGameCode.GDShopButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.MainGameCode.GDRestartButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResumeButtonObjects1Objects = Hashtable.newFrom({"ResumeButton": gdjs.MainGameCode.GDResumeButtonObjects1});gdjs.MainGameCode.eventsList0x72e628 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "diceRoll");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x72e628
gdjs.MainGameCode.eventsList0x72e4c8 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
gdjs.MainGameCode.GDLargeTextboxObjects1.length = 0;

gdjs.MainGameCode.GDRestartButtonObjects1.length = 0;

gdjs.MainGameCode.GDResumeButtonObjects1.length = 0;

gdjs.MainGameCode.GDShopButtonObjects1.length = 0;

{runtimeScene.getVariables().getFromIndex(12).setString("no");
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)).setString("yes");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLargeTextboxObjects1Objects, 100, 200, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects1Objects, 200, 300, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects1Objects, 200, 550, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResumeButtonObjects1Objects, 200, 800, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDResumeButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDResumeButtonObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDLargeTextboxObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDLargeTextboxObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects1[i].setAnimationName("restart");
}
}
{ //Subevents
gdjs.MainGameCode.eventsList0x72e628(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72e4c8
gdjs.MainGameCode.eventsList0x72e360 = function(runtimeScene) {

{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72e4c8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72e360
gdjs.MainGameCode.eventsList0x72e230 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(5)) == "no";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72e360(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72e230
gdjs.MainGameCode.eventsList0x72e100 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72e230(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72e100
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResumeButtonObjects1Objects = Hashtable.newFrom({"ResumeButton": gdjs.MainGameCode.GDResumeButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGameIntroObjects1Objects = Hashtable.newFrom({"GameIntro": gdjs.MainGameCode.GDGameIntroObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDDirectionIndicatorObjects1Objects = Hashtable.newFrom({"DirectionIndicator": gdjs.MainGameCode.GDDirectionIndicatorObjects1});gdjs.MainGameCode.eventsList0x72f3e8 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "diceRoll");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x72f3e8
gdjs.MainGameCode.eventsList0x72f2b8 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDLargeTextboxObjects1.createFrom(runtimeScene.getObjects("LargeTextbox"));
gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.MainGameCode.GDRestartButtonObjects1.createFrom(runtimeScene.getObjects("RestartButton"));
/* Reuse gdjs.MainGameCode.GDResumeButtonObjects1 */
gdjs.MainGameCode.GDShopButtonObjects1.createFrom(runtimeScene.getObjects("ShopButton"));
gdjs.MainGameCode.GDDirectionIndicatorObjects1.length = 0;

gdjs.MainGameCode.GDGameIntroObjects1.length = 0;

{runtimeScene.getVariables().getFromIndex(12).setString("yes");
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDLargeTextboxObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDLargeTextboxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDResumeButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDResumeButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGameIntroObjects1Objects, 240, 450, "UI");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDDirectionIndicatorObjects1Objects, 70, 585, "UI");
}{for(var i = 0, len = gdjs.MainGameCode.GDGameIntroObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDGameIntroObjects1[i].setString("Tap to resume");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDDirectionIndicatorObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDDirectionIndicatorObjects1[i].setString("You are moving to the " + (gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects1[0].getVariables()).getFromIndex(0))));
}
}{runtimeScene.getVariables().getFromIndex(11).setString("yes");
}
{ //Subevents
gdjs.MainGameCode.eventsList0x72f3e8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72f2b8
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.MainGameCode.GDRestartButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGameIntroObjects1Objects = Hashtable.newFrom({"GameIntro": gdjs.MainGameCode.GDGameIntroObjects1});gdjs.MainGameCode.eventsList0x730118 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("normal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("crateNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("slimeNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("gameRomNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("penguinNormal");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "diceRoll");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("botNormal");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(13)) == "no";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{runtimeScene.getVariables().getFromIndex(1).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects1[0].getVariables()).getFromIndex(5))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}}

}


}; //End of gdjs.MainGameCode.eventsList0x730118
gdjs.MainGameCode.eventsList0x72ffa0 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));
gdjs.MainGameCode.GDCoinsGainedObjects1.createFrom(runtimeScene.getObjects("CoinsGained"));
gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDFireball2Objects1.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDFireball3Objects1.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDFireball4Objects1.createFrom(runtimeScene.getObjects("Fireball4"));
gdjs.MainGameCode.GDLargeTextboxObjects1.createFrom(runtimeScene.getObjects("LargeTextbox"));
gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
/* Reuse gdjs.MainGameCode.GDRestartButtonObjects1 */
gdjs.MainGameCode.GDResumeButtonObjects1.createFrom(runtimeScene.getObjects("ResumeButton"));
gdjs.MainGameCode.GDShopButtonObjects1.createFrom(runtimeScene.getObjects("ShopButton"));
gdjs.MainGameCode.GDTextBoxObjects1.createFrom(runtimeScene.getObjects("TextBox"));
gdjs.MainGameCode.GDGameIntroObjects1.length = 0;

{runtimeScene.getVariables().getFromIndex(12).setString("yes");
}{runtimeScene.getVariables().getFromIndex(11).setString("no");
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)).setString("no");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gameClock");
}{for(var i = 0, len = gdjs.MainGameCode.GDTextBoxObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDTextBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDLargeTextboxObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDLargeTextboxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDResumeButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDResumeButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDCoinsGainedObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDCoinsGainedObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setString("none");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(3)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(8)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(7)).setNumber(350);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(4)).setNumber(500);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.VariablesContainer.badVariable).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(5)).setNumber(0);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)).setString("no");
}
}{runtimeScene.getVariables().getFromIndex(8).setNumber(600);
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setPosition(455,1560);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGameIntroObjects1Objects, 240, 521, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDGameIntroObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDGameIntroObjects1[i].setString("Tap to start");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.storage.readStringFromJSONFile("highScore", "", runtimeScene, runtimeScene.getVariables().getFromIndex(0));
}
{ //Subevents
gdjs.MainGameCode.eventsList0x730118(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x72ffa0
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects1Objects = Hashtable.newFrom({"ShopButton": gdjs.MainGameCode.GDShopButtonObjects1});gdjs.MainGameCode.eventsList0x732ad0 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Shop", false);
}}

}


}; //End of gdjs.MainGameCode.eventsList0x732ad0
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects = Hashtable.newFrom({"Fireball": gdjs.MainGameCode.GDFireballObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects = Hashtable.newFrom({"Fireball2": gdjs.MainGameCode.GDFireball2Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects = Hashtable.newFrom({"Fireball3": gdjs.MainGameCode.GDFireball3Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects2Objects = Hashtable.newFrom({"Fireball4": gdjs.MainGameCode.GDFireball4Objects2});gdjs.MainGameCode.eventsList0x733100 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDGameIntroObjects2.createFrom(runtimeScene.getObjects("GameIntro"));
gdjs.MainGameCode.GDInstructionsObjects2.createFrom(runtimeScene.getObjects("Instructions"));
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

gdjs.MainGameCode.GDTapToHoldObjects2.createFrom(runtimeScene.getObjects("TapToHold"));
gdjs.MainGameCode.GDFireballObjects2.length = 0;

gdjs.MainGameCode.GDFireball2Objects2.length = 0;

gdjs.MainGameCode.GDFireball3Objects2.length = 0;

gdjs.MainGameCode.GDFireball4Objects2.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDGameIntroObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGameIntroObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDInstructionsObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDInstructionsObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTapToHoldObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDTapToHoldObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(6)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)).setString("right");
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "gameStart");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gameClock");
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("yes");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects, gdjs.random(192.5), -147, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects, gdjs.random(192.5)+262.5, -147, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects, gdjs.random(192.5)+525, -147, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects2Objects, gdjs.random(192.5)+787.5, -147, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].returnVariable(gdjs.MainGameCode.GDFireballObjects2[i].getVariables().getFromIndex(2)).setNumber(600);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].returnVariable(gdjs.MainGameCode.GDFireballObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].returnVariable(gdjs.MainGameCode.GDFireballObjects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{runtimeScene.getVariables().getFromIndex(13).setString("no");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x733100
gdjs.MainGameCode.eventsList0x734420 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDDirectionIndicatorObjects1.createFrom(runtimeScene.getObjects("DirectionIndicator"));
gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDFireball2Objects1.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDFireball3Objects1.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDFireball4Objects1.createFrom(runtimeScene.getObjects("Fireball4"));
gdjs.MainGameCode.GDGameIntroObjects1.createFrom(runtimeScene.getObjects("GameIntro"));
gdjs.MainGameCode.GDInstructionsObjects1.createFrom(runtimeScene.getObjects("Instructions"));
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
gdjs.MainGameCode.GDTapToHoldObjects1.createFrom(runtimeScene.getObjects("TapToHold"));
{for(var i = 0, len = gdjs.MainGameCode.GDDirectionIndicatorObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDDirectionIndicatorObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGameIntroObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDGameIntroObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDInstructionsObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTapToHoldObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDTapToHoldObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects1[i].returnVariable(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{runtimeScene.getVariables().getFromIndex(13).setString("no");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x734420
gdjs.MainGameCode.eventsList0x732fb0 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(11)) == "no";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x733100(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(11)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x734420(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x732fb0
gdjs.MainGameCode.eventsList0x732e38 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(12)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x732fb0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x732e38
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainGameCode.GDPlayerObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLeftCollideObjects1Objects = Hashtable.newFrom({"LeftCollide": gdjs.MainGameCode.GDLeftCollideObjects1});gdjs.MainGameCode.eventsList0x735b50 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hitWall.ogg", false, 50, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x735b50
gdjs.MainGameCode.eventsList0x735870 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x735b50(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].flipX(true);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x735870
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainGameCode.GDPlayerObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRightCollideObjects1Objects = Hashtable.newFrom({"RightCollide": gdjs.MainGameCode.GDRightCollideObjects1});gdjs.MainGameCode.eventsList0x736460 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hitWall.ogg", false, 50, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}}

}


}; //End of gdjs.MainGameCode.eventsList0x736460
gdjs.MainGameCode.eventsList0x7361b8 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x736460(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x7361b8
gdjs.MainGameCode.eventsList0x736ac8 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].addPolarForce(0, (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(4))), 0);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x736ac8
gdjs.MainGameCode.eventsList0x736e88 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].addPolarForce(180, (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(4))), 0);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x736e88
gdjs.MainGameCode.eventsList0x737e50 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(8)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)).sub(2);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x737e50
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTurboButtonObjects3Objects = Hashtable.newFrom({"TurboButton": gdjs.MainGameCode.GDTurboButtonObjects3});gdjs.MainGameCode.eventsList0x7385c0 = function(runtimeScene) {

{

gdjs.MainGameCode.GDPlayerObjects4.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects4[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(8)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects4[k] = gdjs.MainGameCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects4[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(10)).setString("off");
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects4.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects4[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(8)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects4[k] = gdjs.MainGameCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects4[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(10)).setString("on");
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects4.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects4[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(10)) == "on" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects4[k] = gdjs.MainGameCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects4[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(8)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects4[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(9)).add(200);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects4[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects4[i].getVariables().getFromIndex(4)).add(200);
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects3[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects3[i].getVariables().getFromIndex(10)) == "off" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects3[k] = gdjs.MainGameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects3[i].getVariables().getFromIndex(8)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects3[i].getVariables().getFromIndex(4)).sub(200);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects3[i].getVariables().getFromIndex(9)).sub(200);
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x7385c0
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTurboButtonObjects2Objects = Hashtable.newFrom({"TurboButton": gdjs.MainGameCode.GDTurboButtonObjects2});gdjs.MainGameCode.eventsList0x7393b8 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(10)).setString("none");
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x7393b8
gdjs.MainGameCode.eventsList0x7384a0 = function(runtimeScene) {

{

gdjs.MainGameCode.GDTurboButtonObjects3.createFrom(runtimeScene.getObjects("TurboButton"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTurboButtonObjects3Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x7385c0(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDTurboButtonObjects2.createFrom(runtimeScene.getObjects("TurboButton"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTurboButtonObjects2Objects, runtimeScene, true, true);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x7393b8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x7384a0
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects = Hashtable.newFrom({"Fireball": gdjs.MainGameCode.GDFireballObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects = Hashtable.newFrom({"ResetBox": gdjs.MainGameCode.GDResetBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects = Hashtable.newFrom({"Fireball": gdjs.MainGameCode.GDFireballObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects = Hashtable.newFrom({"Fireball2": gdjs.MainGameCode.GDFireball2Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects = Hashtable.newFrom({"ResetBox": gdjs.MainGameCode.GDResetBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects = Hashtable.newFrom({"Fireball2": gdjs.MainGameCode.GDFireball2Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects = Hashtable.newFrom({"Fireball3": gdjs.MainGameCode.GDFireball3Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects = Hashtable.newFrom({"ResetBox": gdjs.MainGameCode.GDResetBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects = Hashtable.newFrom({"Fireball3": gdjs.MainGameCode.GDFireball3Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects2Objects = Hashtable.newFrom({"Fireball4": gdjs.MainGameCode.GDFireball4Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects = Hashtable.newFrom({"ResetBox": gdjs.MainGameCode.GDResetBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects2Objects = Hashtable.newFrom({"Fireball4": gdjs.MainGameCode.GDFireball4Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects = Hashtable.newFrom({"Fireball": gdjs.MainGameCode.GDFireballObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGameCode.GDPlayerObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects2Objects = Hashtable.newFrom({"TextBox": gdjs.MainGameCode.GDTextBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects2Objects = Hashtable.newFrom({"RestartButton": gdjs.MainGameCode.GDRestartButtonObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects2Objects = Hashtable.newFrom({"ShopButton": gdjs.MainGameCode.GDShopButtonObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.MainGameCode.GDCoinObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects2Objects = Hashtable.newFrom({"CoinsGained": gdjs.MainGameCode.GDCoinsGainedObjects2});gdjs.MainGameCode.eventsList0x73b010 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hitProjectile.ogg", false, 50, 1);
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("hit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("crateHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("slimeHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("gameRomHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("penguinHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) + ")Flash");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("botHit");
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x73b010
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects = Hashtable.newFrom({"Fireball2": gdjs.MainGameCode.GDFireball2Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGameCode.GDPlayerObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects2Objects = Hashtable.newFrom({"TextBox": gdjs.MainGameCode.GDTextBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects2Objects = Hashtable.newFrom({"RestartButton": gdjs.MainGameCode.GDRestartButtonObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects2Objects = Hashtable.newFrom({"ShopButton": gdjs.MainGameCode.GDShopButtonObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.MainGameCode.GDCoinObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects2Objects = Hashtable.newFrom({"CoinsGained": gdjs.MainGameCode.GDCoinsGainedObjects2});gdjs.MainGameCode.eventsList0x73d188 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hitProjectile.ogg", false, 50, 1);
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("hit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("crateHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("slimeHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("gameRomHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("penguinHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) + ")Flash");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("botHit");
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x73d188
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects = Hashtable.newFrom({"Fireball3": gdjs.MainGameCode.GDFireball3Objects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGameCode.GDPlayerObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects2Objects = Hashtable.newFrom({"TextBox": gdjs.MainGameCode.GDTextBoxObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects2Objects = Hashtable.newFrom({"RestartButton": gdjs.MainGameCode.GDRestartButtonObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects2Objects = Hashtable.newFrom({"ShopButton": gdjs.MainGameCode.GDShopButtonObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.MainGameCode.GDCoinObjects2});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects2Objects = Hashtable.newFrom({"CoinsGained": gdjs.MainGameCode.GDCoinsGainedObjects2});gdjs.MainGameCode.eventsList0x73f408 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hitProjectile.ogg", false, 50, 1);
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("hit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("crateHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("slimeHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("gameRomHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("penguinHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects3.createFrom(gdjs.MainGameCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects3[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) + ")Flash");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("botHit");
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x73f408
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects1Objects = Hashtable.newFrom({"Fireball4": gdjs.MainGameCode.GDFireball4Objects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainGameCode.GDPlayerObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects1Objects = Hashtable.newFrom({"TextBox": gdjs.MainGameCode.GDTextBoxObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects1Objects = Hashtable.newFrom({"RestartButton": gdjs.MainGameCode.GDRestartButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects1Objects = Hashtable.newFrom({"ShopButton": gdjs.MainGameCode.GDShopButtonObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.MainGameCode.GDCoinObjects1});gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects1Objects = Hashtable.newFrom({"CoinsGained": gdjs.MainGameCode.GDCoinsGainedObjects1});gdjs.MainGameCode.eventsList0x741648 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "hitProjectile.ogg", false, 50, 1);
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("hit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("crateHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("slimeHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("gameRomHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("penguinHit");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) + ")Flash");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setAnimationName("botHit");
}
}}

}


}; //End of gdjs.MainGameCode.eventsList0x741648
gdjs.MainGameCode.eventsList0x737cf0 = function(runtimeScene) {

{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x737e50(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects2[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(8)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects2[k] = gdjs.MainGameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(7)).add(2);
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x7384a0(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setString("yes");
}
}}

}


{

gdjs.MainGameCode.GDFireballObjects2.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDResetBoxObjects2.createFrom(runtimeScene.getObjects("ResetBox"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireballObjects2 */
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects, gdjs.random(192.5), -147, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].returnVariable(gdjs.MainGameCode.GDFireballObjects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].returnVariable(gdjs.MainGameCode.GDFireballObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(5)).add(1);
}
}}

}


{

gdjs.MainGameCode.GDFireball2Objects2.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDResetBoxObjects2.createFrom(runtimeScene.getObjects("ResetBox"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireball2Objects2 */
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects, gdjs.random(192.5)+262.5, -147, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(5)).add(1);
}
}}

}


{

gdjs.MainGameCode.GDFireball3Objects2.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDResetBoxObjects2.createFrom(runtimeScene.getObjects("ResetBox"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireball3Objects2 */
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects, gdjs.random(192.5)+525, -147, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(5)).add(1);
}
}}

}


{

gdjs.MainGameCode.GDFireball4Objects2.createFrom(runtimeScene.getObjects("Fireball4"));
gdjs.MainGameCode.GDResetBoxObjects2.createFrom(runtimeScene.getObjects("ResetBox"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResetBoxObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireball4Objects2 */
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);

{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects2Objects, gdjs.random(192.5)+787.5, -147, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects2[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.random(600)+gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(5)).add(1);
}
}}

}


{

gdjs.MainGameCode.GDFireballObjects2.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireballObjects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireballObjects2 */
gdjs.MainGameCode.GDFireball2Objects2.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDFireball3Objects2.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDFireball4Objects2.createFrom(runtimeScene.getObjects("Fireball4"));
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
gdjs.MainGameCode.GDCoinObjects2.length = 0;

gdjs.MainGameCode.GDCoinsGainedObjects2.length = 0;

gdjs.MainGameCode.GDRestartButtonObjects2.length = 0;

gdjs.MainGameCode.GDShopButtonObjects2.length = 0;

gdjs.MainGameCode.GDTextBoxObjects2.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(6)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("no");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects2Objects, 100, 530, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects2Objects, 200, 850, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects2Objects, 200, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects2Objects, 425, 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects2Objects, 530, 410, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDCoinsGainedObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDCoinsGainedObjects2[i].setString("+ " + (gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects2[i].setAnimationName("playAgain");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTextBoxObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDTextBoxObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(1).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}{runtimeScene.getVariables().getFromIndex(12).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(13).setString("yes");
}
{ //Subevents
gdjs.MainGameCode.eventsList0x73b010(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDFireball2Objects2.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball2Objects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDFireballObjects2.createFrom(runtimeScene.getObjects("Fireball"));
/* Reuse gdjs.MainGameCode.GDFireball2Objects2 */
gdjs.MainGameCode.GDFireball3Objects2.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDFireball4Objects2.createFrom(runtimeScene.getObjects("Fireball4"));
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
gdjs.MainGameCode.GDCoinObjects2.length = 0;

gdjs.MainGameCode.GDCoinsGainedObjects2.length = 0;

gdjs.MainGameCode.GDRestartButtonObjects2.length = 0;

gdjs.MainGameCode.GDShopButtonObjects2.length = 0;

gdjs.MainGameCode.GDTextBoxObjects2.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(6)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("no");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects2Objects, 100, 530, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects2Objects, 200, 850, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects2Objects, 200, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects2Objects, 425, 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects2Objects, 530, 410, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDCoinsGainedObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDCoinsGainedObjects2[i].setString("+ " + (gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects2[i].setAnimationName("playAgain");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTextBoxObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDTextBoxObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("hit");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(1).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}{runtimeScene.getVariables().getFromIndex(12).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(13).setString("yes");
}
{ //Subevents
gdjs.MainGameCode.eventsList0x73d188(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDFireball3Objects2.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDPlayerObjects2.createFrom(gdjs.MainGameCode.GDPlayerObjects1);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball3Objects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects2Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDFireballObjects2.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDFireball2Objects2.createFrom(runtimeScene.getObjects("Fireball2"));
/* Reuse gdjs.MainGameCode.GDFireball3Objects2 */
gdjs.MainGameCode.GDFireball4Objects2.createFrom(runtimeScene.getObjects("Fireball4"));
/* Reuse gdjs.MainGameCode.GDPlayerObjects2 */
gdjs.MainGameCode.GDCoinObjects2.length = 0;

gdjs.MainGameCode.GDCoinsGainedObjects2.length = 0;

gdjs.MainGameCode.GDRestartButtonObjects2.length = 0;

gdjs.MainGameCode.GDShopButtonObjects2.length = 0;

gdjs.MainGameCode.GDTextBoxObjects2.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(6)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setString("no");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects2Objects, 100, 530, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects2Objects, 200, 850, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects2Objects, 200, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects2Objects, 425, 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects2Objects, 530, 410, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDCoinsGainedObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDCoinsGainedObjects2[i].setString("+ " + (gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects2[i].setAnimationName("playAgain");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTextBoxObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDTextBoxObjects2[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects2[i].setAnimationName("hit");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(1).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects2[0].getVariables()).getFromIndex(5))));
}{runtimeScene.getVariables().getFromIndex(12).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(13).setString("yes");
}
{ //Subevents
gdjs.MainGameCode.eventsList0x73f408(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDFireball4Objects1.createFrom(runtimeScene.getObjects("Fireball4"));
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDFireball4Objects1Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects1Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDFireball2Objects1.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDFireball3Objects1.createFrom(runtimeScene.getObjects("Fireball3"));
/* Reuse gdjs.MainGameCode.GDFireball4Objects1 */
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
gdjs.MainGameCode.GDCoinObjects1.length = 0;

gdjs.MainGameCode.GDCoinsGainedObjects1.length = 0;

gdjs.MainGameCode.GDRestartButtonObjects1.length = 0;

gdjs.MainGameCode.GDShopButtonObjects1.length = 0;

gdjs.MainGameCode.GDTextBoxObjects1.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)).setString("no");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDTextBoxObjects1Objects, 100, 530, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects1Objects, 200, 850, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects1Objects, 200, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinObjects1Objects, 425, 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDCoinsGainedObjects1Objects, 530, 410, "");
}{for(var i = 0, len = gdjs.MainGameCode.GDCoinsGainedObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDCoinsGainedObjects1[i].setString("+ " + (gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects1[0].getVariables()).getFromIndex(5))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects1[i].setAnimationName("playAgain");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDShopButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDShopButtonObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRestartButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRestartButtonObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTextBoxObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDTextBoxObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setAnimationName("hit");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(1).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects1[0].getVariables()).getFromIndex(5))));
}{runtimeScene.getVariables().getFromIndex(12).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(13).setString("yes");
}
{ //Subevents
gdjs.MainGameCode.eventsList0x741648(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x737cf0
gdjs.MainGameCode.eventsList0x737b78 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x737cf0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainGameCode.eventsList0x737b78
gdjs.MainGameCode.eventsList0xb0a98 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "playSound");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gameStart");
}{gdjs.evtTools.storage.readStringFromJSONFile("highScore", "", runtimeScene, runtimeScene.getVariables().getFromIndex(0));
}{gdjs.evtTools.storage.readStringFromJSONFile("amountOfCoins", "", runtimeScene, runtimeScene.getVariables().getFromIndex(1));
}{gdjs.evtTools.storage.readStringFromJSONFile("skinEquipped", "", runtimeScene, runtimeScene.getVariables().getFromIndex(2));
}{gdjs.evtTools.storage.readStringFromJSONFile("soundEnabled", "", runtimeScene, runtimeScene.getVariables().getFromIndex(3));
}{gdjs.evtTools.storage.readStringFromJSONFile("edgesEnabled", "", runtimeScene, runtimeScene.getVariables().getFromIndex(9));
}{gdjs.evtTools.storage.readStringFromJSONFile("turboSide", "", runtimeScene, runtimeScene.getVariables().getFromIndex(14));
}{gdjs.evtTools.sound.playSound(runtimeScene, "hitWall.ogg", false, 0, 1);
}
{ //Subevents
gdjs.MainGameCode.eventsList0x712860(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(9)) == "0";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(9).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("edgesEnabled", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(9)));
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(9)) == "no";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDEdgeObjects1.createFrom(runtimeScene.getObjects("Edge"));
{for(var i = 0, len = gdjs.MainGameCode.GDEdgeObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDEdgeObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(14)) == "0";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(14).setString("right");
}{gdjs.evtTools.storage.writeStringInJSONFile("turboSide", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(14)));
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(14)) == "right";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDTurboButtonObjects1.createFrom(runtimeScene.getObjects("TurboButton"));
{for(var i = 0, len = gdjs.MainGameCode.GDTurboButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDTurboButtonObjects1[i].setX(800);
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(14)) == "left";
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDTurboButtonObjects1.createFrom(runtimeScene.getObjects("TurboButton"));
{for(var i = 0, len = gdjs.MainGameCode.GDTurboButtonObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDTurboButtonObjects1[i].setX(100);
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDHighScoreObjects1.createFrom(runtimeScene.getObjects("HighScore"));
gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.MainGameCode.GDScoreObjects1.createFrom(runtimeScene.getObjects("Score"));
gdjs.MainGameCode.GDTurboChargeObjects1.createFrom(runtimeScene.getObjects("TurboCharge"));
{for(var i = 0, len = gdjs.MainGameCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDScoreObjects1[i].setString("Score : " + (gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects1[0].getVariables()).getFromIndex(5))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHighScoreObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDHighScoreObjects1[i].setString("Highscore : " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTurboChargeObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDTurboChargeObjects1[i].setWidth((gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDPlayerObjects1[0].getVariables()).getFromIndex(7))));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList0x72abd8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72cd98(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPauseButtonObjects1.createFrom(runtimeScene.getObjects("PauseButton"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPauseButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72e100(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDResumeButtonObjects1.createFrom(runtimeScene.getObjects("ResumeButton"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDResumeButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72f2b8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDRestartButtonObjects1.createFrom(runtimeScene.getObjects("RestartButton"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRestartButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x72ffa0(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDShopButtonObjects1.createFrom(runtimeScene.getObjects("ShopButton"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDShopButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x732ad0(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x732e38(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDFireball2Objects1.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDFireball3Objects1.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDFireball4Objects1.createFrom(runtimeScene.getObjects("Fireball4"));
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(1)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects1[i].returnVariable(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(0)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects1[i].getVariables().getFromIndex(0)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects1[i].getVariables().getFromIndex(0)).setString("no");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects1[i].getVariables().getFromIndex(0)).setString("no");
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(6)) == "no" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));
gdjs.MainGameCode.GDFireball2Objects1.createFrom(runtimeScene.getObjects("Fireball2"));
gdjs.MainGameCode.GDFireball3Objects1.createFrom(runtimeScene.getObjects("Fireball3"));
gdjs.MainGameCode.GDFireball4Objects1.createFrom(runtimeScene.getObjects("Fireball4"));
{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects1[i].returnVariable(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball2Objects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball3Objects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects1[i].returnVariable(gdjs.MainGameCode.GDFireball4Objects1[i].getVariables().getFromIndex(0)).setString("yes");
}
}}

}


{

gdjs.MainGameCode.GDLeftCollideObjects1.createFrom(runtimeScene.getObjects("LeftCollide"));
gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects1Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLeftCollideObjects1Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setString("left");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setX((gdjs.MainGameCode.GDPlayerObjects1[i].getPointX("")) - 1);
}
}
{ //Subevents
gdjs.MainGameCode.eventsList0x735870(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.MainGameCode.GDRightCollideObjects1.createFrom(runtimeScene.getObjects("RightCollide"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPlayerObjects1Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRightCollideObjects1Objects, false, runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].returnVariable(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setString("right");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPlayerObjects1[i].setX((gdjs.MainGameCode.GDPlayerObjects1[i].getPointX("")) + 1);
}
}
{ //Subevents
gdjs.MainGameCode.eventsList0x7361b8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == "right" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x736ac8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == "left" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x736e88(runtimeScene);} //End of subevents
}

}


{

gdjs.MainGameCode.GDFireballObjects1.createFrom(runtimeScene.getObjects("Fireball"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDFireballObjects1[i].getVariableString(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(0)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDFireballObjects1[k] = gdjs.MainGameCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDFireballObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireballObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireballObjects1[i].addPolarForce(90, (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDFireballObjects1[i].getVariables().getFromIndex(1))), 0);
}
}}

}


{

gdjs.MainGameCode.GDFireball2Objects1.createFrom(runtimeScene.getObjects("Fireball2"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDFireball2Objects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDFireball2Objects1[i].getVariableString(gdjs.MainGameCode.GDFireball2Objects1[i].getVariables().getFromIndex(0)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDFireball2Objects1[k] = gdjs.MainGameCode.GDFireball2Objects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDFireball2Objects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireball2Objects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDFireball2Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball2Objects1[i].addPolarForce(90, (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDFireball2Objects1[i].getVariables().getFromIndex(1))), 0);
}
}}

}


{

gdjs.MainGameCode.GDFireball3Objects1.createFrom(runtimeScene.getObjects("Fireball3"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDFireball3Objects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDFireball3Objects1[i].getVariableString(gdjs.MainGameCode.GDFireball3Objects1[i].getVariables().getFromIndex(0)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDFireball3Objects1[k] = gdjs.MainGameCode.GDFireball3Objects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDFireball3Objects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireball3Objects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDFireball3Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball3Objects1[i].addPolarForce(90, (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDFireball3Objects1[i].getVariables().getFromIndex(1))), 0);
}
}}

}


{

gdjs.MainGameCode.GDFireball4Objects1.createFrom(runtimeScene.getObjects("Fireball4"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDFireball4Objects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDFireball4Objects1[i].getVariableString(gdjs.MainGameCode.GDFireball4Objects1[i].getVariables().getFromIndex(0)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDFireball4Objects1[k] = gdjs.MainGameCode.GDFireball4Objects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDFireball4Objects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDFireball4Objects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDFireball4Objects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDFireball4Objects1[i].addPolarForce(90, (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDFireball4Objects1[i].getVariables().getFromIndex(1))), 0);
}
}}

}


{

gdjs.MainGameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPlayerObjects1[i].getVariableString(gdjs.MainGameCode.GDPlayerObjects1[i].getVariables().getFromIndex(2)) == "yes" ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPlayerObjects1[k] = gdjs.MainGameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPlayerObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList0x737b78(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs.MainGameCode.eventsList0xb0a98


gdjs.MainGameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();
gdjs.MainGameCode.GDGameIntroObjects1.length = 0;
gdjs.MainGameCode.GDGameIntroObjects2.length = 0;
gdjs.MainGameCode.GDGameIntroObjects3.length = 0;
gdjs.MainGameCode.GDGameIntroObjects4.length = 0;
gdjs.MainGameCode.GDGameIntroObjects5.length = 0;
gdjs.MainGameCode.GDPlayerObjects1.length = 0;
gdjs.MainGameCode.GDPlayerObjects2.length = 0;
gdjs.MainGameCode.GDPlayerObjects3.length = 0;
gdjs.MainGameCode.GDPlayerObjects4.length = 0;
gdjs.MainGameCode.GDPlayerObjects5.length = 0;
gdjs.MainGameCode.GDRightCollideObjects1.length = 0;
gdjs.MainGameCode.GDRightCollideObjects2.length = 0;
gdjs.MainGameCode.GDRightCollideObjects3.length = 0;
gdjs.MainGameCode.GDRightCollideObjects4.length = 0;
gdjs.MainGameCode.GDRightCollideObjects5.length = 0;
gdjs.MainGameCode.GDLeftCollideObjects1.length = 0;
gdjs.MainGameCode.GDLeftCollideObjects2.length = 0;
gdjs.MainGameCode.GDLeftCollideObjects3.length = 0;
gdjs.MainGameCode.GDLeftCollideObjects4.length = 0;
gdjs.MainGameCode.GDLeftCollideObjects5.length = 0;
gdjs.MainGameCode.GDFireballObjects1.length = 0;
gdjs.MainGameCode.GDFireballObjects2.length = 0;
gdjs.MainGameCode.GDFireballObjects3.length = 0;
gdjs.MainGameCode.GDFireballObjects4.length = 0;
gdjs.MainGameCode.GDFireballObjects5.length = 0;
gdjs.MainGameCode.GDFireball2Objects1.length = 0;
gdjs.MainGameCode.GDFireball2Objects2.length = 0;
gdjs.MainGameCode.GDFireball2Objects3.length = 0;
gdjs.MainGameCode.GDFireball2Objects4.length = 0;
gdjs.MainGameCode.GDFireball2Objects5.length = 0;
gdjs.MainGameCode.GDFireball3Objects1.length = 0;
gdjs.MainGameCode.GDFireball3Objects2.length = 0;
gdjs.MainGameCode.GDFireball3Objects3.length = 0;
gdjs.MainGameCode.GDFireball3Objects4.length = 0;
gdjs.MainGameCode.GDFireball3Objects5.length = 0;
gdjs.MainGameCode.GDFireball4Objects1.length = 0;
gdjs.MainGameCode.GDFireball4Objects2.length = 0;
gdjs.MainGameCode.GDFireball4Objects3.length = 0;
gdjs.MainGameCode.GDFireball4Objects4.length = 0;
gdjs.MainGameCode.GDFireball4Objects5.length = 0;
gdjs.MainGameCode.GDResetBoxObjects1.length = 0;
gdjs.MainGameCode.GDResetBoxObjects2.length = 0;
gdjs.MainGameCode.GDResetBoxObjects3.length = 0;
gdjs.MainGameCode.GDResetBoxObjects4.length = 0;
gdjs.MainGameCode.GDResetBoxObjects5.length = 0;
gdjs.MainGameCode.GDScoreObjects1.length = 0;
gdjs.MainGameCode.GDScoreObjects2.length = 0;
gdjs.MainGameCode.GDScoreObjects3.length = 0;
gdjs.MainGameCode.GDScoreObjects4.length = 0;
gdjs.MainGameCode.GDScoreObjects5.length = 0;
gdjs.MainGameCode.GDPauseButtonObjects1.length = 0;
gdjs.MainGameCode.GDPauseButtonObjects2.length = 0;
gdjs.MainGameCode.GDPauseButtonObjects3.length = 0;
gdjs.MainGameCode.GDPauseButtonObjects4.length = 0;
gdjs.MainGameCode.GDPauseButtonObjects5.length = 0;
gdjs.MainGameCode.GDTextBoxObjects1.length = 0;
gdjs.MainGameCode.GDTextBoxObjects2.length = 0;
gdjs.MainGameCode.GDTextBoxObjects3.length = 0;
gdjs.MainGameCode.GDTextBoxObjects4.length = 0;
gdjs.MainGameCode.GDTextBoxObjects5.length = 0;
gdjs.MainGameCode.GDLargeTextboxObjects1.length = 0;
gdjs.MainGameCode.GDLargeTextboxObjects2.length = 0;
gdjs.MainGameCode.GDLargeTextboxObjects3.length = 0;
gdjs.MainGameCode.GDLargeTextboxObjects4.length = 0;
gdjs.MainGameCode.GDLargeTextboxObjects5.length = 0;
gdjs.MainGameCode.GDResumeButtonObjects1.length = 0;
gdjs.MainGameCode.GDResumeButtonObjects2.length = 0;
gdjs.MainGameCode.GDResumeButtonObjects3.length = 0;
gdjs.MainGameCode.GDResumeButtonObjects4.length = 0;
gdjs.MainGameCode.GDResumeButtonObjects5.length = 0;
gdjs.MainGameCode.GDRestartButtonObjects1.length = 0;
gdjs.MainGameCode.GDRestartButtonObjects2.length = 0;
gdjs.MainGameCode.GDRestartButtonObjects3.length = 0;
gdjs.MainGameCode.GDRestartButtonObjects4.length = 0;
gdjs.MainGameCode.GDRestartButtonObjects5.length = 0;
gdjs.MainGameCode.GDShopButtonObjects1.length = 0;
gdjs.MainGameCode.GDShopButtonObjects2.length = 0;
gdjs.MainGameCode.GDShopButtonObjects3.length = 0;
gdjs.MainGameCode.GDShopButtonObjects4.length = 0;
gdjs.MainGameCode.GDShopButtonObjects5.length = 0;
gdjs.MainGameCode.GDHighScoreObjects1.length = 0;
gdjs.MainGameCode.GDHighScoreObjects2.length = 0;
gdjs.MainGameCode.GDHighScoreObjects3.length = 0;
gdjs.MainGameCode.GDHighScoreObjects4.length = 0;
gdjs.MainGameCode.GDHighScoreObjects5.length = 0;
gdjs.MainGameCode.GDBackgroundObjects1.length = 0;
gdjs.MainGameCode.GDBackgroundObjects2.length = 0;
gdjs.MainGameCode.GDBackgroundObjects3.length = 0;
gdjs.MainGameCode.GDBackgroundObjects4.length = 0;
gdjs.MainGameCode.GDBackgroundObjects5.length = 0;
gdjs.MainGameCode.GDCoinObjects1.length = 0;
gdjs.MainGameCode.GDCoinObjects2.length = 0;
gdjs.MainGameCode.GDCoinObjects3.length = 0;
gdjs.MainGameCode.GDCoinObjects4.length = 0;
gdjs.MainGameCode.GDCoinObjects5.length = 0;
gdjs.MainGameCode.GDCoinsGainedObjects1.length = 0;
gdjs.MainGameCode.GDCoinsGainedObjects2.length = 0;
gdjs.MainGameCode.GDCoinsGainedObjects3.length = 0;
gdjs.MainGameCode.GDCoinsGainedObjects4.length = 0;
gdjs.MainGameCode.GDCoinsGainedObjects5.length = 0;
gdjs.MainGameCode.GDInstructionsObjects1.length = 0;
gdjs.MainGameCode.GDInstructionsObjects2.length = 0;
gdjs.MainGameCode.GDInstructionsObjects3.length = 0;
gdjs.MainGameCode.GDInstructionsObjects4.length = 0;
gdjs.MainGameCode.GDInstructionsObjects5.length = 0;
gdjs.MainGameCode.GDTapToHoldObjects1.length = 0;
gdjs.MainGameCode.GDTapToHoldObjects2.length = 0;
gdjs.MainGameCode.GDTapToHoldObjects3.length = 0;
gdjs.MainGameCode.GDTapToHoldObjects4.length = 0;
gdjs.MainGameCode.GDTapToHoldObjects5.length = 0;
gdjs.MainGameCode.GDEdgeObjects1.length = 0;
gdjs.MainGameCode.GDEdgeObjects2.length = 0;
gdjs.MainGameCode.GDEdgeObjects3.length = 0;
gdjs.MainGameCode.GDEdgeObjects4.length = 0;
gdjs.MainGameCode.GDEdgeObjects5.length = 0;
gdjs.MainGameCode.GDTubroBackgroundObjects1.length = 0;
gdjs.MainGameCode.GDTubroBackgroundObjects2.length = 0;
gdjs.MainGameCode.GDTubroBackgroundObjects3.length = 0;
gdjs.MainGameCode.GDTubroBackgroundObjects4.length = 0;
gdjs.MainGameCode.GDTubroBackgroundObjects5.length = 0;
gdjs.MainGameCode.GDTurboChargeObjects1.length = 0;
gdjs.MainGameCode.GDTurboChargeObjects2.length = 0;
gdjs.MainGameCode.GDTurboChargeObjects3.length = 0;
gdjs.MainGameCode.GDTurboChargeObjects4.length = 0;
gdjs.MainGameCode.GDTurboChargeObjects5.length = 0;
gdjs.MainGameCode.GDTurboButtonObjects1.length = 0;
gdjs.MainGameCode.GDTurboButtonObjects2.length = 0;
gdjs.MainGameCode.GDTurboButtonObjects3.length = 0;
gdjs.MainGameCode.GDTurboButtonObjects4.length = 0;
gdjs.MainGameCode.GDTurboButtonObjects5.length = 0;
gdjs.MainGameCode.GDDirectionIndicatorObjects1.length = 0;
gdjs.MainGameCode.GDDirectionIndicatorObjects2.length = 0;
gdjs.MainGameCode.GDDirectionIndicatorObjects3.length = 0;
gdjs.MainGameCode.GDDirectionIndicatorObjects4.length = 0;
gdjs.MainGameCode.GDDirectionIndicatorObjects5.length = 0;

gdjs.MainGameCode.eventsList0xb0a98(runtimeScene);
return;
}
gdjs['MainGameCode'] = gdjs.MainGameCode;
