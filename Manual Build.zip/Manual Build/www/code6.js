gdjs.SkinsCode = {};
gdjs.SkinsCode.GDBackgroundObjects1= [];
gdjs.SkinsCode.GDBackgroundObjects2= [];
gdjs.SkinsCode.GDBackgroundObjects3= [];
gdjs.SkinsCode.GDBackButtonObjects1= [];
gdjs.SkinsCode.GDBackButtonObjects2= [];
gdjs.SkinsCode.GDBackButtonObjects3= [];
gdjs.SkinsCode.GDTitleObjects1= [];
gdjs.SkinsCode.GDTitleObjects2= [];
gdjs.SkinsCode.GDTitleObjects3= [];
gdjs.SkinsCode.GDStandardTitleObjects1= [];
gdjs.SkinsCode.GDStandardTitleObjects2= [];
gdjs.SkinsCode.GDStandardTitleObjects3= [];
gdjs.SkinsCode.GDBluePlayerSkinObjects1= [];
gdjs.SkinsCode.GDBluePlayerSkinObjects2= [];
gdjs.SkinsCode.GDBluePlayerSkinObjects3= [];
gdjs.SkinsCode.GDBluePlayerPriceObjects1= [];
gdjs.SkinsCode.GDBluePlayerPriceObjects2= [];
gdjs.SkinsCode.GDBluePlayerPriceObjects3= [];
gdjs.SkinsCode.GDBlueBuyButtonObjects1= [];
gdjs.SkinsCode.GDBlueBuyButtonObjects2= [];
gdjs.SkinsCode.GDBlueBuyButtonObjects3= [];
gdjs.SkinsCode.GDBlueEquipButtonObjects1= [];
gdjs.SkinsCode.GDBlueEquipButtonObjects2= [];
gdjs.SkinsCode.GDBlueEquipButtonObjects3= [];
gdjs.SkinsCode.GDCrateTitleObjects1= [];
gdjs.SkinsCode.GDCrateTitleObjects2= [];
gdjs.SkinsCode.GDCrateTitleObjects3= [];
gdjs.SkinsCode.GDCratePlayerSkinObjects1= [];
gdjs.SkinsCode.GDCratePlayerSkinObjects2= [];
gdjs.SkinsCode.GDCratePlayerSkinObjects3= [];
gdjs.SkinsCode.GDCratePlayerPriceObjects1= [];
gdjs.SkinsCode.GDCratePlayerPriceObjects2= [];
gdjs.SkinsCode.GDCratePlayerPriceObjects3= [];
gdjs.SkinsCode.GDCrateBuyButtonObjects1= [];
gdjs.SkinsCode.GDCrateBuyButtonObjects2= [];
gdjs.SkinsCode.GDCrateBuyButtonObjects3= [];
gdjs.SkinsCode.GDCrateEquipButtonObjects1= [];
gdjs.SkinsCode.GDCrateEquipButtonObjects2= [];
gdjs.SkinsCode.GDCrateEquipButtonObjects3= [];
gdjs.SkinsCode.GDSlimeTitleObjects1= [];
gdjs.SkinsCode.GDSlimeTitleObjects2= [];
gdjs.SkinsCode.GDSlimeTitleObjects3= [];
gdjs.SkinsCode.GDSlimePlayerSkinObjects1= [];
gdjs.SkinsCode.GDSlimePlayerSkinObjects2= [];
gdjs.SkinsCode.GDSlimePlayerSkinObjects3= [];
gdjs.SkinsCode.GDSlimePlayerPriceObjects1= [];
gdjs.SkinsCode.GDSlimePlayerPriceObjects2= [];
gdjs.SkinsCode.GDSlimePlayerPriceObjects3= [];
gdjs.SkinsCode.GDSlimeBuyButtonObjects1= [];
gdjs.SkinsCode.GDSlimeBuyButtonObjects2= [];
gdjs.SkinsCode.GDSlimeBuyButtonObjects3= [];
gdjs.SkinsCode.GDSlimeEquipButtonObjects1= [];
gdjs.SkinsCode.GDSlimeEquipButtonObjects2= [];
gdjs.SkinsCode.GDSlimeEquipButtonObjects3= [];
gdjs.SkinsCode.GDPenguinTitleObjects1= [];
gdjs.SkinsCode.GDPenguinTitleObjects2= [];
gdjs.SkinsCode.GDPenguinTitleObjects3= [];
gdjs.SkinsCode.GDPenguinPlayerSkinObjects1= [];
gdjs.SkinsCode.GDPenguinPlayerSkinObjects2= [];
gdjs.SkinsCode.GDPenguinPlayerSkinObjects3= [];
gdjs.SkinsCode.GDPenguinPlayerPriceObjects1= [];
gdjs.SkinsCode.GDPenguinPlayerPriceObjects2= [];
gdjs.SkinsCode.GDPenguinPlayerPriceObjects3= [];
gdjs.SkinsCode.GDPenguinBuyButtonObjects1= [];
gdjs.SkinsCode.GDPenguinBuyButtonObjects2= [];
gdjs.SkinsCode.GDPenguinBuyButtonObjects3= [];
gdjs.SkinsCode.GDPenguinEquipButtonObjects1= [];
gdjs.SkinsCode.GDPenguinEquipButtonObjects2= [];
gdjs.SkinsCode.GDPenguinEquipButtonObjects3= [];
gdjs.SkinsCode.GDDiceTitleObjects1= [];
gdjs.SkinsCode.GDDiceTitleObjects2= [];
gdjs.SkinsCode.GDDiceTitleObjects3= [];
gdjs.SkinsCode.GDDicePlayerSkinObjects1= [];
gdjs.SkinsCode.GDDicePlayerSkinObjects2= [];
gdjs.SkinsCode.GDDicePlayerSkinObjects3= [];
gdjs.SkinsCode.GDDicePlayerPriceObjects1= [];
gdjs.SkinsCode.GDDicePlayerPriceObjects2= [];
gdjs.SkinsCode.GDDicePlayerPriceObjects3= [];
gdjs.SkinsCode.GDDiceBuyButtonObjects1= [];
gdjs.SkinsCode.GDDiceBuyButtonObjects2= [];
gdjs.SkinsCode.GDDiceBuyButtonObjects3= [];
gdjs.SkinsCode.GDDiceEquipButtonObjects1= [];
gdjs.SkinsCode.GDDiceEquipButtonObjects2= [];
gdjs.SkinsCode.GDDiceEquipButtonObjects3= [];
gdjs.SkinsCode.GDGameRomTitleObjects1= [];
gdjs.SkinsCode.GDGameRomTitleObjects2= [];
gdjs.SkinsCode.GDGameRomTitleObjects3= [];
gdjs.SkinsCode.GDGameRomPlayerSkinObjects1= [];
gdjs.SkinsCode.GDGameRomPlayerSkinObjects2= [];
gdjs.SkinsCode.GDGameRomPlayerSkinObjects3= [];
gdjs.SkinsCode.GDGameRomPlayerPriceObjects1= [];
gdjs.SkinsCode.GDGameRomPlayerPriceObjects2= [];
gdjs.SkinsCode.GDGameRomPlayerPriceObjects3= [];
gdjs.SkinsCode.GDGameRomBuyButtonObjects1= [];
gdjs.SkinsCode.GDGameRomBuyButtonObjects2= [];
gdjs.SkinsCode.GDGameRomBuyButtonObjects3= [];
gdjs.SkinsCode.GDGameRomEquipButtonObjects1= [];
gdjs.SkinsCode.GDGameRomEquipButtonObjects2= [];
gdjs.SkinsCode.GDGameRomEquipButtonObjects3= [];
gdjs.SkinsCode.GDBotTitleObjects1= [];
gdjs.SkinsCode.GDBotTitleObjects2= [];
gdjs.SkinsCode.GDBotTitleObjects3= [];
gdjs.SkinsCode.GDBotPlayerSkinObjects1= [];
gdjs.SkinsCode.GDBotPlayerSkinObjects2= [];
gdjs.SkinsCode.GDBotPlayerSkinObjects3= [];
gdjs.SkinsCode.GDBotPlayerPriceObjects1= [];
gdjs.SkinsCode.GDBotPlayerPriceObjects2= [];
gdjs.SkinsCode.GDBotPlayerPriceObjects3= [];
gdjs.SkinsCode.GDBotBuyButtonObjects1= [];
gdjs.SkinsCode.GDBotBuyButtonObjects2= [];
gdjs.SkinsCode.GDBotBuyButtonObjects3= [];
gdjs.SkinsCode.GDBotEquipButtonObjects1= [];
gdjs.SkinsCode.GDBotEquipButtonObjects2= [];
gdjs.SkinsCode.GDBotEquipButtonObjects3= [];
gdjs.SkinsCode.GDCoinObjects1= [];
gdjs.SkinsCode.GDCoinObjects2= [];
gdjs.SkinsCode.GDCoinObjects3= [];
gdjs.SkinsCode.GDAmountOfCoinsObjects1= [];
gdjs.SkinsCode.GDAmountOfCoinsObjects2= [];
gdjs.SkinsCode.GDAmountOfCoinsObjects3= [];
gdjs.SkinsCode.GDYouCannotBuyObjects1= [];
gdjs.SkinsCode.GDYouCannotBuyObjects2= [];
gdjs.SkinsCode.GDYouCannotBuyObjects3= [];

gdjs.SkinsCode.conditionTrue_0 = {val:false};
gdjs.SkinsCode.condition0IsTrue_0 = {val:false};
gdjs.SkinsCode.condition1IsTrue_0 = {val:false};


gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBackButtonObjects1Objects = Hashtable.newFrom({"BackButton": gdjs.SkinsCode.GDBackButtonObjects1});gdjs.SkinsCode.eventsList0x712860 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Shop", false);
}}

}


}; //End of gdjs.SkinsCode.eventsList0x712860
gdjs.SkinsCode.eventsList0x7ce748 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.5, "");
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects1.createFrom(runtimeScene.getObjects("YouCannotBuy"));
{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7ce748
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDCrateBuyButtonObjects1Objects = Hashtable.newFrom({"CrateBuyButton": gdjs.SkinsCode.GDCrateBuyButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects = Hashtable.newFrom({"YouCannotBuy": gdjs.SkinsCode.GDYouCannotBuyObjects2});gdjs.SkinsCode.eventsList0x7d02a8 = function(runtimeScene) {

{

gdjs.SkinsCode.GDCratePlayerSkinObjects2.createFrom(runtimeScene.getObjects("CratePlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDCratePlayerSkinObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDCratePlayerSkinObjects2[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{runtimeScene.getVariables().getFromIndex(2).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects, 50, 1550, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects2.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects2[i].setLayer("frontLayer");
}
}}

}


{

gdjs.SkinsCode.GDCratePlayerSkinObjects1.createFrom(runtimeScene.getObjects("CratePlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDCratePlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDCratePlayerSkinObjects1[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SkinsCode.GDCratePlayerSkinObjects1 */
{runtimeScene.getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDCratePlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDCratePlayerSkinObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(3).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("crateBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d02a8
gdjs.SkinsCode.eventsList0x7d0188 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d02a8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d0188
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDPenguinBuyButtonObjects1Objects = Hashtable.newFrom({"PenguinBuyButton": gdjs.SkinsCode.GDPenguinBuyButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects = Hashtable.newFrom({"YouCannotBuy": gdjs.SkinsCode.GDYouCannotBuyObjects2});gdjs.SkinsCode.eventsList0x7d0f50 = function(runtimeScene) {

{

gdjs.SkinsCode.GDPenguinPlayerSkinObjects2.createFrom(runtimeScene.getObjects("PenguinPlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDPenguinPlayerSkinObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDPenguinPlayerSkinObjects2[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{runtimeScene.getVariables().getFromIndex(2).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects, 50, 1550, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects2.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects2[i].setLayer("frontLayer");
}
}}

}


{

gdjs.SkinsCode.GDPenguinPlayerSkinObjects1.createFrom(runtimeScene.getObjects("PenguinPlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDPenguinPlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDPenguinPlayerSkinObjects1[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SkinsCode.GDPenguinPlayerSkinObjects1 */
{runtimeScene.getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDPenguinPlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDPenguinPlayerSkinObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(5).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("penguinBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(5)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d0f50
gdjs.SkinsCode.eventsList0x7d0dd8 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d0f50(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d0dd8
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDSlimeBuyButtonObjects1Objects = Hashtable.newFrom({"SlimeBuyButton": gdjs.SkinsCode.GDSlimeBuyButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects = Hashtable.newFrom({"YouCannotBuy": gdjs.SkinsCode.GDYouCannotBuyObjects2});gdjs.SkinsCode.eventsList0x7d1c18 = function(runtimeScene) {

{

gdjs.SkinsCode.GDSlimePlayerSkinObjects2.createFrom(runtimeScene.getObjects("SlimePlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDSlimePlayerSkinObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDSlimePlayerSkinObjects2[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{runtimeScene.getVariables().getFromIndex(2).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects, 50, 1550, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects2.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects2[i].setLayer("frontLayer");
}
}}

}


{

gdjs.SkinsCode.GDSlimePlayerSkinObjects1.createFrom(runtimeScene.getObjects("SlimePlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDSlimePlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDSlimePlayerSkinObjects1[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SkinsCode.GDSlimePlayerSkinObjects1 */
{runtimeScene.getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDSlimePlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDSlimePlayerSkinObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(4).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("slimeBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d1c18
gdjs.SkinsCode.eventsList0x7d1ab0 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d1c18(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d1ab0
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDGameRomBuyButtonObjects1Objects = Hashtable.newFrom({"GameRomBuyButton": gdjs.SkinsCode.GDGameRomBuyButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects = Hashtable.newFrom({"YouCannotBuy": gdjs.SkinsCode.GDYouCannotBuyObjects2});gdjs.SkinsCode.eventsList0x7d28c0 = function(runtimeScene) {

{

gdjs.SkinsCode.GDGameRomPlayerSkinObjects2.createFrom(runtimeScene.getObjects("GameRomPlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDGameRomPlayerSkinObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDGameRomPlayerSkinObjects2[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{runtimeScene.getVariables().getFromIndex(2).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects, 50, 1550, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects2.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects2[i].setLayer("frontLayer");
}
}}

}


{

gdjs.SkinsCode.GDGameRomPlayerSkinObjects1.createFrom(runtimeScene.getObjects("GameRomPlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDGameRomPlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDGameRomPlayerSkinObjects1[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SkinsCode.GDGameRomPlayerSkinObjects1 */
{runtimeScene.getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDGameRomPlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDGameRomPlayerSkinObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(7).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("gameRomBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d28c0
gdjs.SkinsCode.eventsList0x7d2748 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d28c0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d2748
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDDiceBuyButtonObjects1Objects = Hashtable.newFrom({"DiceBuyButton": gdjs.SkinsCode.GDDiceBuyButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects = Hashtable.newFrom({"YouCannotBuy": gdjs.SkinsCode.GDYouCannotBuyObjects2});gdjs.SkinsCode.eventsList0x7d3588 = function(runtimeScene) {

{

gdjs.SkinsCode.GDDicePlayerSkinObjects2.createFrom(runtimeScene.getObjects("DicePlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDDicePlayerSkinObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDDicePlayerSkinObjects2[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{runtimeScene.getVariables().getFromIndex(2).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects, 50, 1550, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects2.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects2[i].setLayer("frontLayer");
}
}}

}


{

gdjs.SkinsCode.GDDicePlayerSkinObjects1.createFrom(runtimeScene.getObjects("DicePlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDDicePlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDDicePlayerSkinObjects1[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SkinsCode.GDDicePlayerSkinObjects1 */
{runtimeScene.getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDDicePlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDDicePlayerSkinObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(6).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("diceBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d3588
gdjs.SkinsCode.eventsList0x7d3420 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d3588(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d3420
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBotBuyButtonObjects1Objects = Hashtable.newFrom({"BotBuyButton": gdjs.SkinsCode.GDBotBuyButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects = Hashtable.newFrom({"YouCannotBuy": gdjs.SkinsCode.GDYouCannotBuyObjects2});gdjs.SkinsCode.eventsList0x7d4208 = function(runtimeScene) {

{

gdjs.SkinsCode.GDBotPlayerSkinObjects2.createFrom(runtimeScene.getObjects("BotPlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDBotPlayerSkinObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDBotPlayerSkinObjects2[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{runtimeScene.getVariables().getFromIndex(2).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDYouCannotBuyObjects2Objects, 50, 1550, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDYouCannotBuyObjects2.length ;i < len;++i) {
    gdjs.SkinsCode.GDYouCannotBuyObjects2[i].setLayer("frontLayer");
}
}}

}


{

gdjs.SkinsCode.GDBotPlayerSkinObjects1.createFrom(runtimeScene.getObjects("BotPlayerSkin"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDBotPlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDBotPlayerSkinObjects1[0].getVariables()).getFromIndex(0)));
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SkinsCode.GDBotPlayerSkinObjects1 */
{runtimeScene.getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.SkinsCode.GDBotPlayerSkinObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SkinsCode.GDBotPlayerSkinObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("amountOfCoins", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(8).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("botBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d4208
gdjs.SkinsCode.eventsList0x7d40a0 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d4208(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d40a0
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDCrateEquipButtonObjects1Objects = Hashtable.newFrom({"CrateEquipButton": gdjs.SkinsCode.GDCrateEquipButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDPenguinEquipButtonObjects1Objects = Hashtable.newFrom({"PenguinEquipButton": gdjs.SkinsCode.GDPenguinEquipButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDSlimeEquipButtonObjects1Objects = Hashtable.newFrom({"SlimeEquipButton": gdjs.SkinsCode.GDSlimeEquipButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDGameRomEquipButtonObjects1Objects = Hashtable.newFrom({"GameRomEquipButton": gdjs.SkinsCode.GDGameRomEquipButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDDiceEquipButtonObjects1Objects = Hashtable.newFrom({"DiceEquipButton": gdjs.SkinsCode.GDDiceEquipButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBotEquipButtonObjects1Objects = Hashtable.newFrom({"BotEquipButton": gdjs.SkinsCode.GDBotEquipButtonObjects1});gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDCrateEquipButtonObjects1Objects = Hashtable.newFrom({"CrateEquipButton": gdjs.SkinsCode.GDCrateEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d6988 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDCrateEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDCrateEquipButtonObjects1[k] = gdjs.SkinsCode.GDCrateEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDCrateEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("crate");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d6988
gdjs.SkinsCode.eventsList0x7d6810 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d6988(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d6810
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDPenguinEquipButtonObjects1Objects = Hashtable.newFrom({"PenguinEquipButton": gdjs.SkinsCode.GDPenguinEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d6fd0 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDPenguinEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDPenguinEquipButtonObjects1[k] = gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("penguin");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d6fd0
gdjs.SkinsCode.eventsList0x7d6e48 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d6fd0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d6e48
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDSlimeEquipButtonObjects1Objects = Hashtable.newFrom({"SlimeEquipButton": gdjs.SkinsCode.GDSlimeEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d7618 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDSlimeEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDSlimeEquipButtonObjects1[k] = gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("slime");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d7618
gdjs.SkinsCode.eventsList0x7d7490 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d7618(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d7490
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDGameRomEquipButtonObjects1Objects = Hashtable.newFrom({"GameRomEquipButton": gdjs.SkinsCode.GDGameRomEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d7c60 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDGameRomEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDGameRomEquipButtonObjects1[k] = gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("gameRom");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d7c60
gdjs.SkinsCode.eventsList0x7d7ad8 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d7c60(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d7ad8
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDDiceEquipButtonObjects1Objects = Hashtable.newFrom({"DiceEquipButton": gdjs.SkinsCode.GDDiceEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d8298 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDDiceEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDDiceEquipButtonObjects1[k] = gdjs.SkinsCode.GDDiceEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDDiceEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("dice");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d8298
gdjs.SkinsCode.eventsList0x7d8120 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d8298(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d8120
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBlueEquipButtonObjects1Objects = Hashtable.newFrom({"BlueEquipButton": gdjs.SkinsCode.GDBlueEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d88c0 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDBlueEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDBlueEquipButtonObjects1[k] = gdjs.SkinsCode.GDBlueEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDBlueEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("blue");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d88c0
gdjs.SkinsCode.eventsList0x7d8748 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d88c0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d8748
gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBotEquipButtonObjects1Objects = Hashtable.newFrom({"BotEquipButton": gdjs.SkinsCode.GDBotEquipButtonObjects1});gdjs.SkinsCode.eventsList0x7d8ee8 = function(runtimeScene) {

{

/* Reuse gdjs.SkinsCode.GDBotEquipButtonObjects1 */

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SkinsCode.GDBotEquipButtonObjects1.length;i<l;++i) {
    if ( gdjs.SkinsCode.GDBotEquipButtonObjects1[i].isCurrentAnimationName("equip") ) {
        gdjs.SkinsCode.condition0IsTrue_0.val = true;
        gdjs.SkinsCode.GDBotEquipButtonObjects1[k] = gdjs.SkinsCode.GDBotEquipButtonObjects1[i];
        ++k;
    }
}
gdjs.SkinsCode.GDBotEquipButtonObjects1.length = k;}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("bot");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


}; //End of gdjs.SkinsCode.eventsList0x7d8ee8
gdjs.SkinsCode.eventsList0x7d8d70 = function(runtimeScene) {

{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d8ee8(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.SkinsCode.eventsList0x7d8d70
gdjs.SkinsCode.eventsList0xb0a98 = function(runtimeScene) {

{

gdjs.SkinsCode.GDBackButtonObjects1.createFrom(runtimeScene.getObjects("BackButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBackButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x712860(runtimeScene);} //End of subevents
}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDAmountOfCoinsObjects1.createFrom(runtimeScene.getObjects("AmountOfCoins"));
{gdjs.evtTools.storage.readStringFromJSONFile("skinEquipped", "", runtimeScene, runtimeScene.getVariables().getFromIndex(0));
}{gdjs.evtTools.storage.readStringFromJSONFile("amountOfCoins", "", runtimeScene, runtimeScene.getVariables().getFromIndex(1));
}{gdjs.evtTools.storage.readStringFromJSONFile("crateBought", "", runtimeScene, runtimeScene.getVariables().getFromIndex(3));
}{gdjs.evtTools.storage.readStringFromJSONFile("slimeBought", "", runtimeScene, runtimeScene.getVariables().getFromIndex(4));
}{gdjs.evtTools.storage.readStringFromJSONFile("penguinBought", "", runtimeScene, runtimeScene.getVariables().getFromIndex(5));
}{gdjs.evtTools.storage.readStringFromJSONFile("diceBought", "", runtimeScene, runtimeScene.getVariables().getFromIndex(6));
}{gdjs.evtTools.storage.readStringFromJSONFile("gameRomBought", "", runtimeScene, runtimeScene.getVariables().getFromIndex(7));
}{gdjs.evtTools.storage.readStringFromJSONFile("botBought", "", runtimeScene, runtimeScene.getVariables().getFromIndex(8));
}{for(var i = 0, len = gdjs.SkinsCode.GDAmountOfCoinsObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDAmountOfCoinsObjects1[i].setString(": " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7ce748(runtimeScene);} //End of subevents
}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setString("blue");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("crateBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(5)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(5).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("penguinBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(5)));
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("slimeBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)));
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(7).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("gameRomBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7)));
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("diceBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)));
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)) == "0";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(8).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("botBought", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)));
}}

}


{

gdjs.SkinsCode.GDCrateBuyButtonObjects1.createFrom(runtimeScene.getObjects("CrateBuyButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDCrateBuyButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d0188(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDPenguinBuyButtonObjects1.createFrom(runtimeScene.getObjects("PenguinBuyButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDPenguinBuyButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d0dd8(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDSlimeBuyButtonObjects1.createFrom(runtimeScene.getObjects("SlimeBuyButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDSlimeBuyButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d1ab0(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDGameRomBuyButtonObjects1.createFrom(runtimeScene.getObjects("GameRomBuyButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDGameRomBuyButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d2748(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDDiceBuyButtonObjects1.createFrom(runtimeScene.getObjects("DiceBuyButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDDiceBuyButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d3420(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDBotBuyButtonObjects1.createFrom(runtimeScene.getObjects("BotBuyButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBotBuyButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d40a0(runtimeScene);} //End of subevents
}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDCrateBuyButtonObjects1.createFrom(runtimeScene.getObjects("CrateBuyButton"));
gdjs.SkinsCode.GDCratePlayerPriceObjects1.createFrom(runtimeScene.getObjects("CratePlayerPrice"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.length = 0;

{for(var i = 0, len = gdjs.SkinsCode.GDCrateBuyButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateBuyButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDCrateEquipButtonObjects1Objects, 385, 670, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDCratePlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCratePlayerPriceObjects1[i].setString("Bought");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCratePlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCratePlayerPriceObjects1[i].setX(390);
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(5)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDPenguinBuyButtonObjects1.createFrom(runtimeScene.getObjects("PenguinBuyButton"));
gdjs.SkinsCode.GDPenguinPlayerPriceObjects1.createFrom(runtimeScene.getObjects("PenguinPlayerPrice"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length = 0;

{for(var i = 0, len = gdjs.SkinsCode.GDPenguinBuyButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinBuyButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDPenguinEquipButtonObjects1Objects, 735, 670, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinPlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinPlayerPriceObjects1[i].setString("Bought");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinPlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinPlayerPriceObjects1[i].setX(730);
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDSlimeBuyButtonObjects1.createFrom(runtimeScene.getObjects("SlimeBuyButton"));
gdjs.SkinsCode.GDSlimePlayerPriceObjects1.createFrom(runtimeScene.getObjects("SlimePlayerPrice"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length = 0;

{for(var i = 0, len = gdjs.SkinsCode.GDSlimeBuyButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeBuyButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDSlimeEquipButtonObjects1Objects, 45, 1120, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimePlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimePlayerPriceObjects1[i].setString("Bought");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimePlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimePlayerPriceObjects1[i].setX(45);
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDGameRomBuyButtonObjects1.createFrom(runtimeScene.getObjects("GameRomBuyButton"));
gdjs.SkinsCode.GDGameRomPlayerPriceObjects1.createFrom(runtimeScene.getObjects("GameRomPlayerPrice"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length = 0;

{for(var i = 0, len = gdjs.SkinsCode.GDGameRomBuyButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomBuyButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDGameRomEquipButtonObjects1Objects, 385, 1120, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomPlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomPlayerPriceObjects1[i].setString("Bought");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomPlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomPlayerPriceObjects1[i].setX(390);
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDDiceBuyButtonObjects1.createFrom(runtimeScene.getObjects("DiceBuyButton"));
gdjs.SkinsCode.GDDicePlayerPriceObjects1.createFrom(runtimeScene.getObjects("DicePlayerPrice"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.length = 0;

{for(var i = 0, len = gdjs.SkinsCode.GDDiceBuyButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceBuyButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDDiceEquipButtonObjects1Objects, 735, 1120, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDDicePlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDicePlayerPriceObjects1[i].setString("Bought");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDicePlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDicePlayerPriceObjects1[i].setX(730);
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)) == "yes";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBotBuyButtonObjects1.createFrom(runtimeScene.getObjects("BotBuyButton"));
gdjs.SkinsCode.GDBotPlayerPriceObjects1.createFrom(runtimeScene.getObjects("BotPlayerPrice"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.length = 0;

{for(var i = 0, len = gdjs.SkinsCode.GDBotBuyButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotBuyButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBotEquipButtonObjects1Objects, 45, 1570, "");
}{for(var i = 0, len = gdjs.SkinsCode.GDBotPlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotPlayerPriceObjects1[i].setString("Bought");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotPlayerPriceObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotPlayerPriceObjects1[i].setX(45);
}
}}

}


{

gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDCrateEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d6810(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDPenguinEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d6e48(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDSlimeEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d7490(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDGameRomEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d7ad8(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDDiceEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d8120(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBlueEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d8748(runtimeScene);} //End of subevents
}

}


{

gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));

gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SkinsCode.mapOfGDgdjs_46SkinsCode_46GDBotEquipButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SkinsCode.eventsList0x7d8d70(runtimeScene);} //End of subevents
}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "blue";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equipped");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equip");
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "crate";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equipped");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equip");
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "slime";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equipped");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equip");
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "gameRom";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equipped");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equip");
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "penguin";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equipped");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equip");
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "dice";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equipped");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equip");
}
}}

}


{


gdjs.SkinsCode.condition0IsTrue_0.val = false;
{
gdjs.SkinsCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)) == "bot";
}if (gdjs.SkinsCode.condition0IsTrue_0.val) {
gdjs.SkinsCode.GDBlueEquipButtonObjects1.createFrom(runtimeScene.getObjects("BlueEquipButton"));
gdjs.SkinsCode.GDBotEquipButtonObjects1.createFrom(runtimeScene.getObjects("BotEquipButton"));
gdjs.SkinsCode.GDCrateEquipButtonObjects1.createFrom(runtimeScene.getObjects("CrateEquipButton"));
gdjs.SkinsCode.GDDiceEquipButtonObjects1.createFrom(runtimeScene.getObjects("DiceEquipButton"));
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.createFrom(runtimeScene.getObjects("GameRomEquipButton"));
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.createFrom(runtimeScene.getObjects("PenguinEquipButton"));
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.createFrom(runtimeScene.getObjects("SlimeEquipButton"));
{for(var i = 0, len = gdjs.SkinsCode.GDBlueEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBlueEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDCrateEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDCrateEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDSlimeEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDPenguinEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDDiceEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDDiceEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDGameRomEquipButtonObjects1[i].setAnimationName("equip");
}
}{for(var i = 0, len = gdjs.SkinsCode.GDBotEquipButtonObjects1.length ;i < len;++i) {
    gdjs.SkinsCode.GDBotEquipButtonObjects1[i].setAnimationName("equipped");
}
}}

}


{


{
}

}


}; //End of gdjs.SkinsCode.eventsList0xb0a98


gdjs.SkinsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();
gdjs.SkinsCode.GDBackgroundObjects1.length = 0;
gdjs.SkinsCode.GDBackgroundObjects2.length = 0;
gdjs.SkinsCode.GDBackgroundObjects3.length = 0;
gdjs.SkinsCode.GDBackButtonObjects1.length = 0;
gdjs.SkinsCode.GDBackButtonObjects2.length = 0;
gdjs.SkinsCode.GDBackButtonObjects3.length = 0;
gdjs.SkinsCode.GDTitleObjects1.length = 0;
gdjs.SkinsCode.GDTitleObjects2.length = 0;
gdjs.SkinsCode.GDTitleObjects3.length = 0;
gdjs.SkinsCode.GDStandardTitleObjects1.length = 0;
gdjs.SkinsCode.GDStandardTitleObjects2.length = 0;
gdjs.SkinsCode.GDStandardTitleObjects3.length = 0;
gdjs.SkinsCode.GDBluePlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDBluePlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDBluePlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDBluePlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDBluePlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDBluePlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDBlueBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDBlueBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDBlueBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDBlueEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDBlueEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDBlueEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDCrateTitleObjects1.length = 0;
gdjs.SkinsCode.GDCrateTitleObjects2.length = 0;
gdjs.SkinsCode.GDCrateTitleObjects3.length = 0;
gdjs.SkinsCode.GDCratePlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDCratePlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDCratePlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDCratePlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDCratePlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDCratePlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDCrateBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDCrateBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDCrateBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDCrateEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDCrateEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDCrateEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDSlimeTitleObjects1.length = 0;
gdjs.SkinsCode.GDSlimeTitleObjects2.length = 0;
gdjs.SkinsCode.GDSlimeTitleObjects3.length = 0;
gdjs.SkinsCode.GDSlimePlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDSlimePlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDSlimePlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDSlimePlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDSlimePlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDSlimePlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDSlimeBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDSlimeBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDSlimeBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDSlimeEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDSlimeEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDSlimeEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDPenguinTitleObjects1.length = 0;
gdjs.SkinsCode.GDPenguinTitleObjects2.length = 0;
gdjs.SkinsCode.GDPenguinTitleObjects3.length = 0;
gdjs.SkinsCode.GDPenguinPlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDPenguinPlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDPenguinPlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDPenguinPlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDPenguinPlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDPenguinPlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDPenguinBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDPenguinBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDPenguinBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDPenguinEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDPenguinEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDPenguinEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDDiceTitleObjects1.length = 0;
gdjs.SkinsCode.GDDiceTitleObjects2.length = 0;
gdjs.SkinsCode.GDDiceTitleObjects3.length = 0;
gdjs.SkinsCode.GDDicePlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDDicePlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDDicePlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDDicePlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDDicePlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDDicePlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDDiceBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDDiceBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDDiceBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDDiceEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDDiceEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDDiceEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDGameRomTitleObjects1.length = 0;
gdjs.SkinsCode.GDGameRomTitleObjects2.length = 0;
gdjs.SkinsCode.GDGameRomTitleObjects3.length = 0;
gdjs.SkinsCode.GDGameRomPlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDGameRomPlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDGameRomPlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDGameRomPlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDGameRomPlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDGameRomPlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDGameRomBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDGameRomBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDGameRomBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDGameRomEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDGameRomEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDGameRomEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDBotTitleObjects1.length = 0;
gdjs.SkinsCode.GDBotTitleObjects2.length = 0;
gdjs.SkinsCode.GDBotTitleObjects3.length = 0;
gdjs.SkinsCode.GDBotPlayerSkinObjects1.length = 0;
gdjs.SkinsCode.GDBotPlayerSkinObjects2.length = 0;
gdjs.SkinsCode.GDBotPlayerSkinObjects3.length = 0;
gdjs.SkinsCode.GDBotPlayerPriceObjects1.length = 0;
gdjs.SkinsCode.GDBotPlayerPriceObjects2.length = 0;
gdjs.SkinsCode.GDBotPlayerPriceObjects3.length = 0;
gdjs.SkinsCode.GDBotBuyButtonObjects1.length = 0;
gdjs.SkinsCode.GDBotBuyButtonObjects2.length = 0;
gdjs.SkinsCode.GDBotBuyButtonObjects3.length = 0;
gdjs.SkinsCode.GDBotEquipButtonObjects1.length = 0;
gdjs.SkinsCode.GDBotEquipButtonObjects2.length = 0;
gdjs.SkinsCode.GDBotEquipButtonObjects3.length = 0;
gdjs.SkinsCode.GDCoinObjects1.length = 0;
gdjs.SkinsCode.GDCoinObjects2.length = 0;
gdjs.SkinsCode.GDCoinObjects3.length = 0;
gdjs.SkinsCode.GDAmountOfCoinsObjects1.length = 0;
gdjs.SkinsCode.GDAmountOfCoinsObjects2.length = 0;
gdjs.SkinsCode.GDAmountOfCoinsObjects3.length = 0;
gdjs.SkinsCode.GDYouCannotBuyObjects1.length = 0;
gdjs.SkinsCode.GDYouCannotBuyObjects2.length = 0;
gdjs.SkinsCode.GDYouCannotBuyObjects3.length = 0;

gdjs.SkinsCode.eventsList0xb0a98(runtimeScene);
return;
}
gdjs['SkinsCode'] = gdjs.SkinsCode;
