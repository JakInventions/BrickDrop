gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDTitleObjects1= [];
gdjs.MainMenuCode.GDTitleObjects2= [];
gdjs.MainMenuCode.GDTitleObjects3= [];
gdjs.MainMenuCode.GDTitleObjects4= [];
gdjs.MainMenuCode.GDPlayerPreviewObjects1= [];
gdjs.MainMenuCode.GDPlayerPreviewObjects2= [];
gdjs.MainMenuCode.GDPlayerPreviewObjects3= [];
gdjs.MainMenuCode.GDPlayerPreviewObjects4= [];
gdjs.MainMenuCode.GDLeftCollideObjects1= [];
gdjs.MainMenuCode.GDLeftCollideObjects2= [];
gdjs.MainMenuCode.GDLeftCollideObjects3= [];
gdjs.MainMenuCode.GDLeftCollideObjects4= [];
gdjs.MainMenuCode.GDRightCollideObjects1= [];
gdjs.MainMenuCode.GDRightCollideObjects2= [];
gdjs.MainMenuCode.GDRightCollideObjects3= [];
gdjs.MainMenuCode.GDRightCollideObjects4= [];
gdjs.MainMenuCode.GDStartButtonObjects1= [];
gdjs.MainMenuCode.GDStartButtonObjects2= [];
gdjs.MainMenuCode.GDStartButtonObjects3= [];
gdjs.MainMenuCode.GDStartButtonObjects4= [];
gdjs.MainMenuCode.GDBackgroundObjects1= [];
gdjs.MainMenuCode.GDBackgroundObjects2= [];
gdjs.MainMenuCode.GDBackgroundObjects3= [];
gdjs.MainMenuCode.GDBackgroundObjects4= [];
gdjs.MainMenuCode.GDSoundButtonObjects1= [];
gdjs.MainMenuCode.GDSoundButtonObjects2= [];
gdjs.MainMenuCode.GDSoundButtonObjects3= [];
gdjs.MainMenuCode.GDSoundButtonObjects4= [];
gdjs.MainMenuCode.GDSkinsButtonObjects1= [];
gdjs.MainMenuCode.GDSkinsButtonObjects2= [];
gdjs.MainMenuCode.GDSkinsButtonObjects3= [];
gdjs.MainMenuCode.GDSkinsButtonObjects4= [];
gdjs.MainMenuCode.GDcookieWarningObjects1= [];
gdjs.MainMenuCode.GDcookieWarningObjects2= [];
gdjs.MainMenuCode.GDcookieWarningObjects3= [];
gdjs.MainMenuCode.GDcookieWarningObjects4= [];
gdjs.MainMenuCode.GDloadOutScreenObjects1= [];
gdjs.MainMenuCode.GDloadOutScreenObjects2= [];
gdjs.MainMenuCode.GDloadOutScreenObjects3= [];
gdjs.MainMenuCode.GDloadOutScreenObjects4= [];

gdjs.MainMenuCode.conditionTrue_0 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_0 = {val:false};


gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDloadOutScreenObjects1Objects = Hashtable.newFrom({"loadOutScreen": gdjs.MainMenuCode.GDloadOutScreenObjects1});gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDcookieWarningObjects2Objects = Hashtable.newFrom({"cookieWarning": gdjs.MainMenuCode.GDcookieWarningObjects2});gdjs.MainMenuCode.eventsList0x7191b8 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(90);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.1, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(80);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.2, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(70);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.3, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(60);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.4, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(50);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.5, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(40);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.6, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(30);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.7, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(20);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.8, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(10);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 2.9, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects3.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects3[i].setOpacity(0);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "cookieTimer");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects2.createFrom(runtimeScene.getObjects("cookieWarning"));
{for(var i = 0, len = gdjs.MainMenuCode.GDcookieWarningObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDcookieWarningObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(6).setString("no");
}{runtimeScene.getVariables().getFromIndex(7).setString("no");
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x7191b8
gdjs.MainMenuCode.eventsList0x718c88 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7)) == "no";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDcookieWarningObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "cookieTimer");
}{runtimeScene.getVariables().getFromIndex(7).setString("yes");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDcookieWarningObjects2Objects, 150, 1150, "");
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x7191b8(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs.MainMenuCode.eventsList0x718c88
gdjs.MainMenuCode.eventsList0x71ad28 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.025, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(240);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.05, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(230);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.075, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(220);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.10, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(210);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.125, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(200);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.15, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(190);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.175, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(180);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.20, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(170);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.225, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(160);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.25, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(150);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.275, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(140);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.30, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(130);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.325, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(120);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.35, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(110);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.375, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(100);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.40, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(90);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.425, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(80);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.45, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(70);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.475, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(60);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.50, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(50);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.525, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(40);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.55, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(30);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.575, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(20);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.60, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(10);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.625, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects1.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects1[i].setOpacity(0);
}
}{runtimeScene.getVariables().getFromIndex(9).setString("no");
}{runtimeScene.getVariables().getFromIndex(8).setString("yes");
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x71ad28
gdjs.MainMenuCode.eventsList0x71fa50 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "diceRoll");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(5).setNumber(gdjs.random(5) + 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "diceRoll");
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x71fa50
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSoundButtonObjects1Objects = Hashtable.newFrom({"SoundButton": gdjs.MainMenuCode.GDSoundButtonObjects1});gdjs.MainMenuCode.eventsList0x7209b0 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "no";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("soundEnabled", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(3).setString("no");
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x7209b0
gdjs.MainMenuCode.eventsList0x720458 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setString("no");
}{gdjs.evtTools.storage.writeStringInJSONFile("soundEnabled", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(3).setString("yes");
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = !(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "yes");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x7209b0(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x720458
gdjs.MainMenuCode.eventsList0x720328 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x720458(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x720328
gdjs.MainMenuCode.eventsList0x7201c0 = function(runtimeScene) {

{

gdjs.MainMenuCode.GDSoundButtonObjects1.createFrom(runtimeScene.getObjects("SoundButton"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSoundButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x720328(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x7201c0
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSkinsButtonObjects1Objects = Hashtable.newFrom({"SkinsButton": gdjs.MainMenuCode.GDSkinsButtonObjects1});gdjs.MainMenuCode.eventsList0x721140 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Skins", false);
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x721140
gdjs.MainMenuCode.eventsList0x720fd8 = function(runtimeScene) {

{

gdjs.MainMenuCode.GDSkinsButtonObjects1.createFrom(runtimeScene.getObjects("SkinsButton"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDSkinsButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x721140(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x720fd8
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDPlayerPreviewObjects1Objects = Hashtable.newFrom({"PlayerPreview": gdjs.MainMenuCode.GDPlayerPreviewObjects1});gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDLeftCollideObjects1Objects = Hashtable.newFrom({"LeftCollide": gdjs.MainMenuCode.GDLeftCollideObjects1});gdjs.MainMenuCode.eventsList0x7214e8 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDPlayerPreviewObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].flipX(true);
}
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x7214e8
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDPlayerPreviewObjects1Objects = Hashtable.newFrom({"PlayerPreview": gdjs.MainMenuCode.GDPlayerPreviewObjects1});gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRightCollideObjects1Objects = Hashtable.newFrom({"RightCollide": gdjs.MainMenuCode.GDRightCollideObjects1});gdjs.MainMenuCode.eventsList0x721960 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDPlayerPreviewObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].flipX(false);
}
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x721960
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDStartButtonObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.MainMenuCode.GDStartButtonObjects2});gdjs.MainMenuCode.eventsList0x722418 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.popStartedTouch(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDStartButtonObjects2 */
{for(var i = 0, len = gdjs.MainMenuCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDStartButtonObjects2[i].setAnimationName("clicked");
}
}{runtimeScene.getVariables().getFromIndex(4).setString("yes");
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x722418
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDStartButtonObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.MainMenuCode.GDStartButtonObjects2});gdjs.MainMenuCode.eventsList0x722a10 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects3.createFrom(runtimeScene.getObjects("PlayerPreview"));
gdjs.MainMenuCode.GDStartButtonObjects3.createFrom(gdjs.MainMenuCode.GDStartButtonObjects2);

{for(var i = 0, len = gdjs.MainMenuCode.GDStartButtonObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDStartButtonObjects3[i].setAnimationName("unclicked");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "");
}{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects3.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects3[i].returnVariable(gdjs.MainMenuCode.GDPlayerPreviewObjects3[i].getVariables().getFromIndex(1)).setString("yes");
}
}}

}


{


{
}

}


}; //End of gdjs.MainMenuCode.eventsList0x722a10
gdjs.MainMenuCode.eventsList0x722898 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.popEndedTouch(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x722a10(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x722898
gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.MainMenuCode.GDStartButtonObjects1});gdjs.MainMenuCode.eventsList0x723020 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.popEndedTouch(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDStartButtonObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDStartButtonObjects1[i].setAnimationName("unclicked");
}
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x723020
gdjs.MainMenuCode.eventsList0x7222b0 = function(runtimeScene) {

{

gdjs.MainMenuCode.GDStartButtonObjects2.createFrom(runtimeScene.getObjects("StartButton"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDStartButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x722418(runtimeScene);} //End of subevents
}

}


{

gdjs.MainMenuCode.GDStartButtonObjects2.createFrom(runtimeScene.getObjects("StartButton"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDStartButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x722898(runtimeScene);} //End of subevents
}

}


{

gdjs.MainMenuCode.GDStartButtonObjects1.createFrom(runtimeScene.getObjects("StartButton"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDStartButtonObjects1Objects, runtimeScene, true, true);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x723020(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x7222b0
gdjs.MainMenuCode.eventsList0x723578 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.025, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(10);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.05, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(20);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.075, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(30);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.10, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(40);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.125, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(50);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.15, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(60);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.175, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(70);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.20, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(80);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.225, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(90);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.25, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(100);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.275, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(110);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.30, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(120);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.325, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(130);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.35, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(140);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.375
, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(150);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.40, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(160);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.425, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(170);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.45, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(180);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.475, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(190);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.50, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(200);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.525, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(210);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.55, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(220);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.575, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(230);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.60, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(240);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.625, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDloadOutScreenObjects2.createFrom(runtimeScene.getObjects("loadOutScreen"));
{for(var i = 0, len = gdjs.MainMenuCode.GDloadOutScreenObjects2.length ;i < len;++i) {
    gdjs.MainMenuCode.GDloadOutScreenObjects2[i].setOpacity(250);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.65, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainGame", false);
}}

}


}; //End of gdjs.MainMenuCode.eventsList0x723578
gdjs.MainMenuCode.eventsList0x723400 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.25, "");
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(8).setString("no");
}
{ //Subevents
gdjs.MainMenuCode.eventsList0x723578(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.MainMenuCode.eventsList0x723400
gdjs.MainMenuCode.eventsList0xb0a98 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
gdjs.MainMenuCode.GDloadOutScreenObjects1.length = 0;

{gdjs.evtTools.storage.readStringFromJSONFile("soundEnabled", "", runtimeScene, runtimeScene.getVariables().getFromIndex(1));
}{gdjs.evtTools.storage.readStringFromJSONFile("skinEquipped", "", runtimeScene, runtimeScene.getVariables().getFromIndex(2));
}{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].flipX(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDloadOutScreenObjects1Objects, 0, 0, "loudOut");
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x718c88(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(9)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x71ad28(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "0";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setString("yes");
}{gdjs.evtTools.storage.writeStringInJSONFile("soundEnabled", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDSoundButtonObjects1.createFrom(runtimeScene.getObjects("SoundButton"));
{for(var i = 0, len = gdjs.MainMenuCode.GDSoundButtonObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDSoundButtonObjects1[i].setAnimationName("sound");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "no";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDSoundButtonObjects1.createFrom(runtimeScene.getObjects("SoundButton"));
{for(var i = 0, len = gdjs.MainMenuCode.GDSoundButtonObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDSoundButtonObjects1[i].setAnimationName("noSound");
}
}}

}


{


{
{runtimeScene.getVariables().getFromIndex(3).setString("no");
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "0";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setString("blue");
}{gdjs.evtTools.storage.writeStringInJSONFile("skinEquipped", "", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "blue";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("blue");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "crate";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("crate");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "penguin";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("penguin");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "slime";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("slime");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameRom";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("gameRom");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "dice";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("dice(" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(5)) + ")");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList0x71fa50(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "bot";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].setAnimationName("bot");
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x7201c0(runtimeScene);} //End of subevents
}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x720fd8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainMenuCode.GDLeftCollideObjects1.createFrom(runtimeScene.getObjects("LeftCollide"));
gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDPlayerPreviewObjects1Objects, gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDLeftCollideObjects1Objects, false, runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDPlayerPreviewObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].returnVariable(gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariables().getFromIndex(0)).setString("left");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList0x7214e8(runtimeScene);} //End of subevents
}

}


{

gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));
gdjs.MainMenuCode.GDRightCollideObjects1.createFrom(runtimeScene.getObjects("RightCollide"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDPlayerPreviewObjects1Objects, gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDRightCollideObjects1Objects, false, runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDPlayerPreviewObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].returnVariable(gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariables().getFromIndex(0)).setString("right");
}
}
{ //Subevents
gdjs.MainMenuCode.eventsList0x721960(runtimeScene);} //End of subevents
}

}


{

gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariableString(gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariables().getFromIndex(0)) == "left" ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDPlayerPreviewObjects1[k] = gdjs.MainMenuCode.GDPlayerPreviewObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDPlayerPreviewObjects1.length = k;}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDPlayerPreviewObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].addPolarForce(180, 500, 0);
}
}}

}


{

gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariableString(gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariables().getFromIndex(0)) == "right" ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDPlayerPreviewObjects1[k] = gdjs.MainMenuCode.GDPlayerPreviewObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDPlayerPreviewObjects1.length = k;}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDPlayerPreviewObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].addPolarForce(0, 500, 0);
}
}}

}


{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(8)) == "yes";
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x7222b0(runtimeScene);} //End of subevents
}

}


{

gdjs.MainMenuCode.GDPlayerPreviewObjects1.createFrom(runtimeScene.getObjects("PlayerPreview"));

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDPlayerPreviewObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariableString(gdjs.MainMenuCode.GDPlayerPreviewObjects1[i].getVariables().getFromIndex(1)) == "yes" ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDPlayerPreviewObjects1[k] = gdjs.MainMenuCode.GDPlayerPreviewObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDPlayerPreviewObjects1.length = k;}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0x723400(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs.MainMenuCode.eventsList0xb0a98


gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();
gdjs.MainMenuCode.GDTitleObjects1.length = 0;
gdjs.MainMenuCode.GDTitleObjects2.length = 0;
gdjs.MainMenuCode.GDTitleObjects3.length = 0;
gdjs.MainMenuCode.GDTitleObjects4.length = 0;
gdjs.MainMenuCode.GDPlayerPreviewObjects1.length = 0;
gdjs.MainMenuCode.GDPlayerPreviewObjects2.length = 0;
gdjs.MainMenuCode.GDPlayerPreviewObjects3.length = 0;
gdjs.MainMenuCode.GDPlayerPreviewObjects4.length = 0;
gdjs.MainMenuCode.GDLeftCollideObjects1.length = 0;
gdjs.MainMenuCode.GDLeftCollideObjects2.length = 0;
gdjs.MainMenuCode.GDLeftCollideObjects3.length = 0;
gdjs.MainMenuCode.GDLeftCollideObjects4.length = 0;
gdjs.MainMenuCode.GDRightCollideObjects1.length = 0;
gdjs.MainMenuCode.GDRightCollideObjects2.length = 0;
gdjs.MainMenuCode.GDRightCollideObjects3.length = 0;
gdjs.MainMenuCode.GDRightCollideObjects4.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects1.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects2.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects3.length = 0;
gdjs.MainMenuCode.GDStartButtonObjects4.length = 0;
gdjs.MainMenuCode.GDBackgroundObjects1.length = 0;
gdjs.MainMenuCode.GDBackgroundObjects2.length = 0;
gdjs.MainMenuCode.GDBackgroundObjects3.length = 0;
gdjs.MainMenuCode.GDBackgroundObjects4.length = 0;
gdjs.MainMenuCode.GDSoundButtonObjects1.length = 0;
gdjs.MainMenuCode.GDSoundButtonObjects2.length = 0;
gdjs.MainMenuCode.GDSoundButtonObjects3.length = 0;
gdjs.MainMenuCode.GDSoundButtonObjects4.length = 0;
gdjs.MainMenuCode.GDSkinsButtonObjects1.length = 0;
gdjs.MainMenuCode.GDSkinsButtonObjects2.length = 0;
gdjs.MainMenuCode.GDSkinsButtonObjects3.length = 0;
gdjs.MainMenuCode.GDSkinsButtonObjects4.length = 0;
gdjs.MainMenuCode.GDcookieWarningObjects1.length = 0;
gdjs.MainMenuCode.GDcookieWarningObjects2.length = 0;
gdjs.MainMenuCode.GDcookieWarningObjects3.length = 0;
gdjs.MainMenuCode.GDcookieWarningObjects4.length = 0;
gdjs.MainMenuCode.GDloadOutScreenObjects1.length = 0;
gdjs.MainMenuCode.GDloadOutScreenObjects2.length = 0;
gdjs.MainMenuCode.GDloadOutScreenObjects3.length = 0;
gdjs.MainMenuCode.GDloadOutScreenObjects4.length = 0;

gdjs.MainMenuCode.eventsList0xb0a98(runtimeScene);
return;
}
gdjs['MainMenuCode'] = gdjs.MainMenuCode;
